const product = document.querySelector('.product');
const bg = document.querySelector('.bg');
const logo = document.querySelector('.logo');
const overline = document.querySelector('.overline');
const elemans = gsap.utils.toArray('.eleman');
const elemanFloatTweens = [];

let productFloat;
let cycleTimeline;

const resetScene = () => {
  gsap.set(product, { x: -200, y: 0, rotation: -12, opacity: 0, scale: 1 });
  gsap.set(bg, { y: 140, opacity: 0 });
  gsap.set([logo], { y: 80, opacity: 0 });
  gsap.set([overline], { x: 400, y: 0, opacity: 0 });
  gsap.set(elemans, {
    opacity: 0,
    y: 36,
    scale: 0.85,
    rotation: (index) => (index % 2 === 0 ? -10 : 12),
    filter: 'blur(12px)',
    transformOrigin: '50% 50%',
  });
};

resetScene();

const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

cycleTimeline = tl
  .to(product, { x: 0, rotation: 0, opacity: 1, duration: 0.9 })
  .add(() => {
    productFloat = gsap.to(product, {
      rotation: 6,
      duration: 0.5,
      yoyo: true,
      repeat: -1,
      ease: 'sine.inOut',
    });
  }, '>')
  .to(bg, { y: 0, opacity: 1, duration: 0.7, ease: 'power2.out' }, '+=1')
  .to(
    [logo],
    { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out', stagger: 0.1 },
    '+=0.111'
  )
  .to(
    [overline],
    { x: 265, opacity: 1, duration: 0.6, ease: 'power2.out', stagger: 0.1 },
    '+=0.5'
  );
tl.to(
  elemans,
  {
    opacity: 1,
    y: 0,
    scale: 1,
    rotation: 0,
    filter: 'blur(0px)',
    duration: 0.9,
    ease: 'elastic.out(1, 0.75)',
    stagger: {
      each: 0.18,
      from: 'center',
    },
  },
  '-=0.2'
).add(() => {
  elemans.forEach((eleman, index) => {
    const tween = gsap.to(eleman, {
      keyframes: [
        {
          y: '+=' + (index % 2 === 0 ? 5 : -5),
          x: '+=' + (index % 2 === 0 ? -2 : 2),
          duration: 1.4,
        },
        {
          y: '-=' + (index % 2 === 0 ? 5 : -5),
          x: '-=' + (index % 2 === 0 ? -2 : 2),
          duration: 1.4,
        },
      ],
      ease: 'sine.inOut',
      repeat: -1,
      delay: index * 0.12,
      yoyo: true,
    });

    elemanFloatTweens.push(tween);
  });

  gsap.delayedCall(8, () => {
    elemanFloatTweens.forEach((tween) => tween.kill());
    elemanFloatTweens.length = 0;

    if (productFloat) {
      productFloat.kill();
      productFloat = null;
    }

    const exitTl = gsap.timeline();

    exitTl
      .to(elemans, {
        opacity: 0,
        scale: 0.9,
        y: (index) => (index % 2 === 0 ? '-=30' : '+=30'),
        filter: 'blur(10px)',
        duration: 0.55,
        ease: 'power2.inOut',
        stagger: 0.14,
      })
      .to(
        overline,
        {
          y: 140,
          opacity: 0,
          duration: 0.6,
          ease: 'power2.in',
        },
        '+=0.1'
      )
      .to(
        logo,
        {
          y: 80,
          opacity: 0,
          duration: 0.6,
          ease: 'power2.in',
        },
        '<'
      )
      .to(
        bg,
        {
          y: 140,
          opacity: 0,
          duration: 0.6,
          ease: 'power2.in',
        },
        '<'
      )
      .to(
        product,
        {
          x: () =>
            window.innerWidth / 2 -
            (product.getBoundingClientRect().left +
              product.getBoundingClientRect().width / 2),
          y: () => {
            const rect = product.getBoundingClientRect();
            return window.innerHeight / 2 - (rect.top + rect.height / 2);
          },
          scale: 1.1,
          duration: 0.9,
          ease: 'power3.inOut',
        },
        '>'
      )
      .to({}, { duration: 0.5 })
      .to(
        product,
        {
          y: () =>
            '+=' +
            (window.innerHeight / 2 + product.getBoundingClientRect().height),
          scale: 1,
          opacity: 0,
          duration: 0.8,
          ease: 'power2.in',
        },
        '>'
      );

    exitTl.add(() => {
      resetScene();
      cycleTimeline.restart(true);
    });
  });
});
