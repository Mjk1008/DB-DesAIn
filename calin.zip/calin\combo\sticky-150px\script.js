document.addEventListener('DOMContentLoaded', function () {
  const panirPairs = [];
  const contentElement = document.querySelector('.content');
  const contentScrollHeight = contentElement.scrollHeight;
  const itemsCount = Math.round(contentScrollHeight / 150) + 1;
  let currentSlideNumber = 0;
  const panirs = document.querySelectorAll('.panir');
  const products = panirs;
  const cta = document.querySelector('.cta');
  const cta2 = document.querySelector('.cta2');
  const overline = document.querySelector('.overline');
  const smallPanirs = document.querySelectorAll('.small-panir');
  const hand = document.querySelector('.hand');

  panirs.forEach((el) => {
    el.addEventListener('click', (e) => {
      fire_tag(ALL_EVENT_TYPES.CLICK3);
    });
    panirPairs.push([
      el.querySelector('.panir-1'),
      el.querySelector('.panir-2'),
    ]);
  });

  window.addEventListener('message', (e) => {
    if (e.data.type !== 'yn-window-scroll') {
      return;
    }
    handleScroll(e.data.scrolled, e.data.scrolledInPx, e.data.heightOfPage);
  });

  function run(panirPair, duration) {
    let index = 0;
    const toggle = function () {
      panirPair[index].style.opacity = '0';
      panirPair[(index + 1) % 2].style.opacity = '1';
      index = (index + 1) % 2;
    };
    const interval = setInterval(toggle, 200);
    const kill = function () {
      clearInterval(interval);
      index = 1;
      toggle();
    };

    const timeout = setTimeout(kill, duration);

    return () => {
      kill();
      clearTimeout(timeout);
    };
  }

  function init_panir(pair, panir) {
    const time = 1.2;
    run(pair, time * 1000);
    gsap.to(panir, {
      duration: time,
      left: '60px',
      ease: 'linear',
    });
  }

  init_panir(panirPairs[0], panirs[0]);
  init_panir(panirPairs[1], panirs[1]);
  init_panir(panirPairs[2], panirs[2]);
  gsap.to(cta, {
    duration: 1,
    delay: 1,
    bottom: '120px',
    onComplete: () => {
      cta.classList.add('tapesh');
      cta.style.zIndex = '800';
      hand.style.opacity = '1';
      hand.classList.add('tapesh2');
    },
  });

  const openBox = document.querySelector('.open-box');
  const closeBox = document.querySelector('.close-box');
  const stage = document.querySelector('.stage');

  function final_slide() {
    gsap.to(stage, {
      duration: 1,
      bottom: '-100px',
    });
    panirs.forEach((panir, index) => {
      panir.classList.remove('paresh');
      panir.style.transform = `scaleX(-1)`;
      const time = 2;
      run(panirPairs[index], time * 1000);
      gsap.to(panir, {
        duration: time,
        left: '-100px',
        ease: 'linear',
      });
    });
    const bg = document.querySelector('.bg');
    const rightBg = document.querySelector('.right-bg');
    const leftBg = document.querySelector('.left-bg');
    const rightBg2 = document.querySelector('.right-bg2');
    const bg2 = document.querySelector('.bg2');
    const logo = document.querySelector('.logo');
    const runner = document.querySelector('.runner');
    logo.addEventListener('click', () => {
      fire_tag(ALL_EVENT_TYPES.CLICK4);
    });
    setTimeout(() => {
      gsap.to(bg, {
        duration: 1,
        opacity: 0,
      });

      gsap.to(bg2, {
        duration: 1,
        opacity: 1,
      });

      gsap.to(rightBg, {
        duration: 1,
        right: '-100px',
      });

      gsap.to(leftBg, {
        duration: 1,
        left: '-100px',
      });

      gsap.to(rightBg2, {
        duration: 1,
        right: '0',
        opacity: 1,
      });

      gsap.to(closeBox, {
        duration: 1,
        bottom: '-10px',
        height: '100px',
        left: '5%',
      });
      gsap.to(logo, {
        duration: 1,
        bottom: '85px',
        height: '40px',
        right: '10px',
      });

      gsap.fromTo(
        cta2,
        {
          right: '-100px',
          duration: 1,
          delay: 1,
        },
        {
          right: '20px',
          duration: 1,
          opacity: 1,
        }
      );

      gsap.fromTo(
        overline,
        {
          right: '-100px',
          duration: 1,
          delay: 1,
        },
        {
          right: '12px',
          duration: 1,
          opacity: 1,
          onComplete: () => {
            cta2.classList.add('tapesh');
            cta2.addEventListener('click', () => {
              fire_tag(ALL_EVENT_TYPES.CLICK2);
            });
            gsap.to(runner, {
              opacity: 1,
              duration: 1,
            });
            gsap.to('.jumper', {
              bottom: '70px',
              duration: 1,
              delay: 1,
            });
          },
        }
      );
    }, 2000);

    document.querySelector('.door').style.display = 'none';
    openBox.style.display = 'none';
    closeBox.style.opacity = '1';
  }

  function click_handler() {
    if (has_clicked) {
      return;
    }
    cta.remove();
    hand.remove();
    setTimeout(() => {
      final_slide();
    }, 10000);
    paresh(smallPanirs[0]);
    setTimeout(() => {
      paresh(smallPanirs[1]);
    }, 2000);
    setTimeout(() => {
      paresh(smallPanirs[2]);
    }, 4000);
    setTimeout(() => {
      paresh(smallPanirs[3]);
    }, 6000);
    setTimeout(() => {
      paresh(smallPanirs[4]);
    }, 8000);
  }

  let has_clicked = false;
  setTimeout(() => {
    panirs.forEach((el) => {
      el.classList.add('paresh');
      const timeout = setTimeout(() => {
        click_handler();
        has_clicked = true;
      }, 7000);
      document.body.addEventListener('click', (e) => {
        if (has_clicked) {
          return;
        }
        e.preventDefault();
        e.stopPropagation();
        if (e.target.classList.contains('cta')) {
          fire_tag(ALL_EVENT_TYPES.CLICK1);
        }
        clearTimeout(timeout);
        click_handler();
        has_clicked = true;
      });
    });
  }, 1300);

  function paresh(smallPanir) {
    gsap.to(smallPanir, {
      rotate: -360,
      duration: 1,
      bottom: '130px',
      left: 'calc(30% + 80px)',
      right: 'initial',
      ease: 'linear',
    });
    smallPanir.style.zIndex = '9';
    gsap.to(smallPanir, {
      delay: 1,
      rotate: -720,
      duration: 1,
      bottom: '80px',
      left: 'calc(30% + 28px)',
      right: 'initial',
      ease: 'linear',
      onComplete: () => {
        smallPanir.remove();
      },
    });
  }

  function handleProduct(currentNumber, NextNumber) {
    gsap.to(products[currentNumber % products.length], {
      duration: 1,
      opacity: 0,
    });
    gsap.to(products[NextNumber], {
      duration: 1,
      opacity: 1,
    });
  }

  function handleScroll(percent, scrollPx, heightOfPage) {
    const withPercent = heightOfPage < 3500;
    let newSlideNumber = withPercent
      ? Math.round((percent / 300) * (itemsCount - 1))
      : Math.trunc(scrollPx / 500);

    newSlideNumber %= products.length;
    if (newSlideNumber === currentSlideNumber) {
      return;
    }
    handleProduct(currentSlideNumber, newSlideNumber);
    currentSlideNumber = newSlideNumber;
  }

  window.addEventListener('message', (e) => {
    if (e.data.type !== 'yn-window-scroll') {
      return;
    }
    handleScroll(e.data.scrolled, e.data.scrolledInPx, e.data.heightOfPage);
  });
});
