const BASE_URL = 'https://material.uranus-agency.ir';

const API_SILVER = {
  week: `${BASE_URL}/api/average/7days/silver_talasea`,
  month: `${BASE_URL}/api/average/30days/silver_talasea`,
  today: `${BASE_URL}/api/current-day/silver_talasea`,
};

const API_GOLD = {
  week: `${BASE_URL}/api/average/7days/gold_talasea`,
  month: `${BASE_URL}/api/average/30days/gold_talasea`,
  today: `${BASE_URL}/api/current-day/gold_talasea`,
};

let currentMetal = 'silver';
let currentApis = API_SILVER;

let data_7days = [];
let data_30days = [];
let data_today = [];

function toPersianDigits(number) {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return number.toString().replace(/\d/g, (digit) => persianDigits[digit]);
}

async function set_today_datas(apis = currentApis) {
  const res = await fetch(apis.today);
  const body = (await res.json()).filter((el) => el.hour !== 24);
  const lastWithPrice = [...body]
    .reverse()
    .find((row) => row?.price !== null && row?.price !== undefined);
  if (lastWithPrice?.price) {
    setLivePriceValue(lastWithPrice.price);
  }

  data_today = body.map((h) => ({
    hour: `ساعت ${h.hour}`,
    price: h.price,
  }));

  if (!chart) {
    init_chart(data_today);
  } else {
    updateChart(data_today);
  }
  setLivePriceFromData(data_today);
}

set_today_datas();

async function set_7days_datas(apis = currentApis) {
  const res_7days = await fetch(apis.week);
  const body_7days = await res_7days.json();
  data_7days = [];
  for (const row of body_7days) {
    data_7days.push({ hour: row.date, price: row.averagePrice });
  }
}

async function set_30days_datas(apis = currentApis) {
  const res_30days = await fetch(apis.month);
  const body_30days = await res_30days.json();
  data_30days = [];
  for (const row of body_30days) {
    data_30days.push({ hour: row.date, price: row.averagePrice });
  }
}

let fetchTimeout = null;

function schedulePrefetch() {
  if (fetchTimeout) clearTimeout(fetchTimeout);
  fetchTimeout = setTimeout(() => {
    set_7days_datas();
    set_30days_datas();
  }, 2000);
}

schedulePrefetch();

const mychart = document.getElementById('myChart');
const ctx = mychart.getContext('2d');

let chart = null;
const livePriceElement = document.querySelector('.live-price');
const logoElement = document.querySelector('.logo');

function createGradient(top, bottomColor = 'rgba(0,0,0,0)') {
  const g = ctx.createLinearGradient(0, 0, 0, 120);
  g.addColorStop(0, top);
  g.addColorStop(0.7, bottomColor);
  return g;
}

const gradients = {
  silver: createGradient('#6CA9E2', 'white'),
  gold: createGradient('#f1b80c', 'white'),
};

const lineShadow = {
  id: 'lineShadow',
  beforeDatasetsDraw(chart) {
    const { ctx } = chart;
    ctx.save();
    ctx.shadowColor = 'rgba(190, 217, 244, 0.9)';
    ctx.shadowBlur = 10;
    ctx.shadowOffsetY = 3;
  },
  afterDatasetsDraw(chart) {
    chart.ctx.restore();
  },
};
Chart.register(lineShadow);

function getChartTheme(metal) {
  if (metal === 'gold') {
    return {
      gradient: gradients.gold,
      borderColor: 'black',
      pointBackgroundColor: 'white',
      pointBorderColor: 'white',
    };
  }
  return {
    gradient: gradients.silver,
    borderColor: '#002649',
    pointBackgroundColor: '#002649',
    pointBorderColor: '#002649',
  };
}

function applyChartTheme(metal) {
  if (!chart) return;
  const theme = getChartTheme(metal);
  const ds = chart.data.datasets[0];
  ds.backgroundColor = theme.gradient;
  ds.borderColor = theme.borderColor;
  ds.pointBackgroundColor = theme.pointBackgroundColor;
  ds.pointBorderColor = theme.pointBorderColor;
  chart.update(ds);
}

function init_chart(data) {
  const theme = getChartTheme('silver');
  chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: data.map((item) => item.hour),
      datasets: [
        {
          label: 'قیمت',
          data: data.map((item) => Number(item.price)),
          fill: true,
          backgroundColor: theme.gradient,
          borderColor: '#002649',
          borderWidth: 1.5,
          spanGaps: true,
          tension: 0.25,
          pointBackgroundColor: '#002649',
          pointBorderColor: '#002649',
          pointBorderWidth: 1,
          pointHoverRadius: 4,
          pointRadius: 2,
        },
      ],
    },
    options: {
      maintainAspectRatio: false,
      interaction: {
        mode: 'index',
        intersect: false,
      },
      responsive: true,
      scales: {
        x: {
          ticks: {
            font: {
              family: 'YekanBakh',
              size: 6,
            },
            display: true,
            color: '#002649',
            callback: function (value) {
              return toPersianDigits(this.getLabelForValue(value));
            },
          },
          grid: { display: true },
        },
        y: {
          ticks: {
            font: {
              family: 'YekanBakh',
              size: 6,
            },
            display: true,
            color: '#002649',
            callback: function (value) {
              return toPersianDigits(this.getLabelForValue(value));
            },
          },
          grid: { display: true },
        },
      },
      plugins: {
        legend: {
          display: false,
          labels: {
            font: {
              family: 'YekanBakh',
              size: 12,
            },
          },
        },
        tooltip: { enabled: true, intersect: false },
        lineShadow: {},
      },
    },
  });
}

document
  .querySelectorAll('.segmented-control input[type="radio"]')
  .forEach((radio) => {
    radio.addEventListener('change', (e) => {
      if (!radio.checked) return;
      switch (radio.id) {
        case '24hours':
          updateChart(data_today);
          break;
        case 'lastWeek':
          if (!data_7days.length) {
            set_7days_datas().then(() => updateChart(data_7days));
          } else {
            updateChart(data_7days);
          }
          break;
        case 'lastMonth':
          if (!data_30days.length) {
            set_30days_datas().then(() => updateChart(data_30days));
          } else {
            updateChart(data_30days);
          }
          break;
      }
    });
  });

function updateChart(newData) {
  if (!chart) {
    init_chart(newData);
    return;
  }
  chart.data.labels = newData.map((item) => item.hour);
  chart.data.datasets[0].data = newData.map((item) =>
    item.price === null ? null : Number(item.price)
  );
  chart.update();
  setLivePriceFromData(newData);
}

document.querySelector('.timeBox').addEventListener('click', (e) => {
  e.stopPropagation();
  e.preventDefault();
});

const hours = document.querySelector('.hours');
const lastWeek = document.querySelector('.lastWeek');
const lastMonth = document.querySelector('.lastMonth');

const handleHourClick = async () => {
  lastMonth.classList.remove('checked');
  lastWeek.classList.remove('checked');
  hours.classList.add('checked');
  if (!data_today.length) {
    await set_today_datas();
  }
  updateChart(data_today);
};

hours.addEventListener('click', async (e) => {
  fire_tag(ALL_EVENT_TYPES.CLICK1);
  e.stopPropagation();
  e.preventDefault();
  handleHourClick();
});

lastWeek.addEventListener('click', async (e) => {
  fire_tag(ALL_EVENT_TYPES.CLICK2);
  e.stopPropagation();
  e.preventDefault();
  lastMonth.classList.remove('checked');
  lastWeek.classList.add('checked');
  hours.classList.remove('checked');
  if (!data_7days.length) {
    await set_7days_datas();
  }
  updateChart(data_7days);
});

lastMonth.addEventListener('click', async (e) => {
  e.stopPropagation();
  e.preventDefault();
  fire_tag(ALL_EVENT_TYPES.CLICK3);
  lastMonth.classList.add('checked');
  lastWeek.classList.remove('checked');
  hours.classList.remove('checked');

  if (!data_30days.length) {
    await set_30days_datas();
  }
  updateChart(data_30days);
});

function setLivePriceFromData(list) {
  if (!livePriceElement) return;
  const lastWithPrice = [...list]
    .reverse()
    .find((i) => i.price !== null && i.price !== undefined);
  if (!lastWithPrice) {
    livePriceElement.textContent = '-';
    return;
  }
  setLivePriceValue(lastWithPrice.price);
}

function setLivePriceValue(value) {
  if (!livePriceElement) return;
  const num = Number(value);
  if (Number.isNaN(num)) {
    livePriceElement.textContent = '-';
    return;
  }
  const priceStr = num.toLocaleString('fa-IR');
  livePriceElement.textContent = `${toPersianDigits(priceStr)} تومان`;
}

const ctaButtons = document.querySelectorAll('.cta-button');
let ctaIndex = 0;
if (ctaButtons.length > 1) {
  const switchCta = () => {
    const current = ctaButtons[ctaIndex];
    const nextIndex = (ctaIndex + 1) % ctaButtons.length;
    const next = ctaButtons[nextIndex];

    gsap.to(current, {
      duration: 0.35,
      opacity: 0,
      y: 6,
      onComplete: () => {
        current.classList.remove('cta-active');
        next.classList.add('cta-active');
        gsap.fromTo(
          next,
          { opacity: 0, y: 6 },
          { duration: 0.45, opacity: 1, y: 0, ease: 'power2.out' }
        );
      },
    });

    ctaIndex = nextIndex;
  };

  setInterval(switchCta, 5000);
}

const ctaButtonsGold = document.querySelectorAll('.cta-button-gold');
let ctaIndexGold = 0;
if (ctaButtonsGold.length > 1) {
  const switchCtaGold = () => {
    const current = ctaButtonsGold[ctaIndexGold];
    const nextIndex = (ctaIndexGold + 1) % ctaButtonsGold.length;
    const next = ctaButtonsGold[nextIndex];

    gsap.to(current, {
      duration: 0.35,
      opacity: 0,
      y: 6,
      onComplete: () => {
        current.classList.remove('cta-active-gold');
        next.classList.add('cta-active-gold');
        gsap.fromTo(
          next,
          { opacity: 0, y: 6 },
          { duration: 0.45, opacity: 1, y: 0, ease: 'power2.out' }
        );
      },
    });

    ctaIndexGold = nextIndex;
  };

  setInterval(switchCtaGold, 5000);
}

async function updateForCurrentSelection() {
  const checked = document.querySelector(
    '.segmented-control input[type="radio"]:checked'
  );
  if (!checked) return;
  switch (checked.id) {
    case 'lastWeek':
      if (!data_7days.length) await set_7days_datas();
      updateChart(data_7days);
      break;
    case 'lastMonth':
      if (!data_30days.length) await set_30days_datas();
      updateChart(data_30days);
      break;
    default:
      if (!data_today.length) await set_today_datas();
      updateChart(data_today);
  }
}

async function handleMetalChange(metal) {
  fire_tag(ALL_EVENT_TYPES.CLICK5);
  currentMetal = metal;
  currentApis = metal === 'gold' ? API_GOLD : API_SILVER;
  handleHourClick();
  data_today = [];
  data_7days = [];
  data_30days = [];
  if (fetchTimeout) clearTimeout(fetchTimeout);
  if (logoElement) {
    logoElement.classList.remove('fade-in');
    void logoElement.offsetWidth; // restart animation
    logoElement.src = metal === 'gold' ? './logogold.png' : './logo.png';
    logoElement.classList.add('fade-in');
  }
  await set_today_datas();
  schedulePrefetch();
  await updateForCurrentSelection();
  applyChartTheme(currentMetal);
}

const metalButtons = document.querySelectorAll('.metal-btn');
metalButtons.forEach((btn) => {
  btn.addEventListener('click', async (e) => {
    e.stopPropagation();
    e.preventDefault();
    metalButtons.forEach((b) => b.classList.toggle('metal-active', b === btn));
    const isGold = btn.classList.contains('metal-gold');
    if (isGold) {
      document.body.classList.add('gold-mode');
    } else {
      document.body.classList.remove('gold-mode');
    }

    gsap.fromTo(
      btn,
      { scale: 0.96 },
      { duration: 0.25, scale: 1, ease: 'power2.out' }
    );

    await handleMetalChange(isGold ? 'gold' : 'silver');
  });
});
