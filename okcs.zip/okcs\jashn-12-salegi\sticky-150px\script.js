const car = document.querySelector('.car-container');
const car2 = document.querySelector('.car2');
const wheelBack = car.querySelector('.wheel-back');
const wheelFront = car.querySelector('.wheel-front');
const cta = document.querySelector('.cta');
const jashn = document.querySelector('.jashn-container');
const baloon1 = document.querySelector('.baloon1');
const baloon2 = document.querySelector('.baloon2');

car.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK1);
});
cta.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK2);
});
car2.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK3);
});
jashn.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK4);
});

wheelFront.classList.add('rotate');
wheelBack.classList.add('rotate');
gsap.to(car, {
  left: '50%',
  duration: 2,
  ease: 'linear',
  transform: 'translateX(-50%)',
  onComplete: function () {
    wheelFront.classList.remove('rotate');
    wheelBack.classList.remove('rotate');

    setTimeout(() => {
      wheelFront.classList.add('rotate');
      wheelBack.classList.add('rotate');
      gsap.to(car, {
        duration: 2,
        ease: 'linear',
        transform: 'translateX(-250%)',
        onComplete: function () {
          init();
        },
      });
    }, 1000);
  },
});

function init() {
  fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE02);
  gsap.fromTo(
    jashn,
    {
      duration: 1,
      bottom: '200px',
    },
    {
      bottom: 0,
      opacity: 1,
      onComplete: function () {
        gsap.to(baloon1, {
          opacity: 1,
          duration: 0.5,
        });
        gsap.to(baloon2, {
          opacity: 1,
          duration: 0.5,
        });

        setTimeout(function () {
          const fire = document.querySelector('.fire');

          gsap.to(fire, {
            opacity: 1,
            duration: 1,
            onComplete: function () {
              fire.classList.add('fire-rotate');
            },
          });
          final();
        }, 500);
      },
    }
  );
}

function final() {
  fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE03);
  gsap.to('.bg', {
    right: 0,
    opacity: 1,
    duration: 1,
    onComplete: function () {
      gsap.to('.header', { opacity: 1, duration: 1 });
      gsap.to('.overline', { opacity: 1, duration: 1 });
      gsap.to(cta, { opacity: 1, duration: 1 });
      gsap.set('.logo', { opacity: 1 });
      gsap.to('.logo', { top: 0, duration: 1 });
    },
  });

  gsap.fromTo(
    car2,
    {
      opacity: 0,
      scale: 0.1,
      duration: 0.5,
    },
    {
      opacity: 1,
      scale: 1,
      onComplete: function () {
        gsap.to(baloon2, {
          left: '5%',
          zIndex: '-10',
          duration: 1,
          bottom: '100px',
          onComplete: function () {
            setTimeout(function () {
              fire_tag(ALL_EVENT_TYPES.LOOP);
              location.reload();
            }, 15000);
          },
        });
        gsap.to(car2, {
          delay: 1,
          scale: 0.9,
          duration: 1,
          yoyo: true,
          repeat: -1,
          transformOrigin: 'right top',
        });
      },
    }
  );
}
