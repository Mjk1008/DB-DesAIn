const contentElement = document.querySelector('.content');
const contentScrollHeight = contentElement.scrollHeight;
const itemsCount = Math.round(contentScrollHeight / 150) + 1;
let currentSlideNumber = 0;
const products = document.querySelectorAll('.product');
const videoContainer = document.querySelector('.videoContainer');

(function init() {
  products.forEach((value, key) => {
    if (key !== 0) {
      value.style.opacity = '0';
    }
  });
})();

function handleProduct(currentNumber, NextNumber) {
  console.log(NextNumber);
  gsap.to(products[currentNumber % products.length], {
    duration: 0.7,
    opacity: 0,
  });
  gsap.to(products[NextNumber], {
    duration: 0.7,
    opacity: 1,
  });
}

function handleScroll(percent, scrollPx, heightOfPage) {
  const withPercent = heightOfPage < 3500;
  let newSlideNumber = withPercent
    ? Math.round((percent / 300) * (itemsCount - 1))
    : Math.trunc(scrollPx / 700);

  newSlideNumber %= products.length;
  if (newSlideNumber === currentSlideNumber) {
    return;
  }
  handleProduct(currentSlideNumber, newSlideNumber);
  currentSlideNumber = newSlideNumber;
}

window.addEventListener('message', (e) => {
  if (e.data.type !== 'yn-window-scroll') {
    return;
  }
  handleScroll(e.data.scrolled, e.data.scrolledInPx, e.data.heightOfPage);
});

const logo = document.querySelector('.logo');
logo.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK2);
});

products.forEach((product) => {
  product.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK3);
  });
});

function toggleSound() {
  const video = document.getElementById('myVideo');
  video.muted = !video.muted;
}

const cta = document.querySelector('.cta');
cta.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK1);
});

const unmuteButton = document.querySelector('.unmuteButton');
unmuteButton.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  toggleSound();
  fire_tag(ALL_EVENT_TYPES.CLICK4);
});

const car = document.querySelector('.car');

gsap.to(car, {
  duration: 2,
  yoyo: true,
  repeat: -1,
  bottom: '15px',
  right: '-20px',
  height: '52',
});

gsap.to(videoContainer, {
  duration: 1,
  bottom: 0,
  onComplete: () => {
    videoContainer.querySelector('video').play();
  },
});
