const contentElement = document.querySelector('.content');
const contentScrollHeight = contentElement.scrollHeight;
const itemsCount = Math.round(contentScrollHeight / 100);
let currentSlideNumber = 0;
const products = document.querySelectorAll('.product');

(function init() {
  products.forEach((value, key) => {
    if (key !== 0) {
      value.style.opacity = '0';
    }
  });
})();

function handleBackground(currentNumber, NextNumber) {
  gsap.to(products[currentNumber % products.length], {
    duration: 0.7,
    opacity: 0,
  });
  gsap.to(products[NextNumber], {
    duration: 0.7,
    opacity: 1,
  });
}

const logo = document.querySelector('.logo');
logo.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK2);
});

products.forEach((product) => {
  product.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK3);
  });
});
const cta = document.querySelector('.cta');
cta.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK1);
});

function handleScroll(percent, scrollPx, heightOfPage) {
  const withPercent = heightOfPage < 3500;
  let newSlideNumber = withPercent
    ? Math.round((percent / 100) * (itemsCount - 1))
    : Math.trunc(scrollPx / 700);

  // if (newSlideNumber >= itemsCount) {
  //     newSlideNumber =
  //         newSlideNumber - itemsCount * Math.trunc(newSlideNumber / itemsCount);
  // }
  newSlideNumber %= products.length;
  if (newSlideNumber === currentSlideNumber) {
    return;
  }
  handleBackground(currentSlideNumber, newSlideNumber);
  currentSlideNumber = newSlideNumber;
}

window.addEventListener('message', (e) => {
  if (e.data.type !== 'yn-window-scroll') {
    return;
  }
  handleScroll(e.data.scrolled, e.data.scrolledInPx, e.data.heightOfPage);
});

products.forEach((product, key) => {
  product.addEventListener('click', () => {
    fire_tag(ACTIONS.CLICK_PRODUCT);
    console.log('product');
  });
});
