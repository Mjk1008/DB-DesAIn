document.addEventListener('DOMContentLoaded', function () {
  const banner = document.querySelector('.banner');
  const logo = document.querySelector('.logo');
  const intro = document.querySelector('.intro');
  const bg = document.querySelector('.bg');
  const car = document.querySelector('.car');
  const card = document.querySelector('.card');
  const cta = document.querySelector('.cta');
  const outro = document.querySelector('.outro');

  gsap.to(bg, {
    duration: 1,
    transform: 'scaleX(1)',
  });

  gsap.to(banner, {
    duration: 1,
    opacity: 1,
    delay: 1,
  });

  setTimeout(() => {
    gsap.to(logo, {
      transform: 'translate(0,-50%)',
      opacity: 1,
      duration: 1,
    });
    gsap.to(intro, {
      opacity: 1,
      duration: 1,
    });
  }, 2000);

  const planet = document.querySelector('.uranus-planet');
  const ring = document.querySelector('.ring');

  let interval = null;
  let flag = true;
  setTimeout(function () {
    gsap.to(intro, { opacity: 0, duration: 1 });
    gsap.to(banner, { opacity: 0, duration: 1 });
    gsap.to(logo, {
      left: '50%',
      height: '50px',
      xPercent: -50,
      yPercent: -56,
      delay: 1,
      duration: 1,
      onComplete: () => {
        gsap.to(planet, { opacity: 1, duration: 1 });
        gsap.to(ring, {
          opacity: 1,
          duration: 1,
          onComplete: () => {
            interval = setInterval(() => {
              if (flag) {
                gsap.to(car, { opacity: 0, duration: 1 });
                gsap.to(logo, { opacity: 1, duration: 1 });
              } else {
                gsap.to(logo, { opacity: 0, duration: 1 });
                gsap.to(car, { opacity: 1, duration: 1 });
              }
              flag = !flag;
            }, 5000);

            setTimeout(() => {
              clearInterval(interval);
              flag = true;
              gsap.to(logo, {
                opacity: 1,
                yPercent: -50,
                duration: 1,
                left: '7%',
                transform: 'translate(0,-50%)',
              });
              gsap.to(car, {
                opacity: 0,
                duration: 0.5,
                onComplete: () => {
                  car.remove();
                },
              });
              gsap.to(ring, {
                opacity: 0,
                duration: 0.5,
              });
              gsap.to(planet, {
                opacity: 0,
                duration: 0.5,
              });
              gsap.to(car, {
                opacity: 0,
                duration: 0.5,
              });
              gsap.to(card, {
                opacity: 1,
                duration: 1,
              });
              gsap.to(cta, {
                opacity: 1,
                duration: 1,
                right: '10%',
                top: '75%',
              });
              gsap.to(outro, {
                opacity: 1,
                duration: 1,
                right: '8%',
              });
              setTimeout(function () {
                location.reload();
              }, 10000);
            }, 20000);
          },
        });
      },
    });
  }, 5000);

  const orbitProducts = Array.from(document.querySelectorAll('.orbit-product'));

  if (!orbitProducts.length) {
    return;
  }

  const total = orbitProducts.length;
  let rotationOffset = 0;

  const updateTransforms = () => {
    const radiusX = 150;
    const radiusY = 45;
    const depth = 1;
    const minScale = 0.5;
    const maxScale = 0.8;
    const floatAmplitude = 1;

    orbitProducts.forEach((product, index) => {
      const angle = (index / total) * Math.PI * 2 + rotationOffset;
      const cos = Math.cos(angle);
      const sin = Math.sin(angle);
      const x = cos * radiusX;
      const ellipseY = sin * radiusY;
      const floatY =
        Math.sin(angle * 2 + rotationOffset * 1.6) * floatAmplitude;
      const y = ellipseY + floatY;
      const z = sin * depth;

      // محاسبه scale: محصولات جلوتر (z بیشتر) بزرگ‌تر باشند
      const normalized = (z + depth) / (depth * 2); // مقدار بین 0 تا 1
      const scale = minScale + normalized * (maxScale - minScale);

      const translateX = x - product.offsetWidth / 2;
      const translateY = y - product.offsetHeight / 2;
      product.style.transform = `translate3d(${translateX}px, ${translateY}px, ${z}px) scale(${scale.toFixed(3)})`;

      // product.style.opacity = Math.min(1, Math.max(0.5, 0.6 + normalized * 0.4));
      product.style.zIndex = Math.round(z + depth + 200);
    });
  };

  updateTransforms();

  let lastTime = 0;
  const speed = 0.00006;
  let isDragging = false;
  let dragStartX = 0;
  let dragStartRotation = 0;
  let lastDragX = 0;
  let lastDragTime = 0;
  let autoRotationEnabled = true;

  const orbitTrack = document.getElementById('orbitTrack');
  const planetSystem = orbitTrack ? orbitTrack.closest('.planet-system') : null;

  const tick = (timestamp) => {
    if (!lastTime) {
      lastTime = timestamp;
    }
    const delta = timestamp - lastTime;
    lastTime = timestamp;

    if (!isDragging && autoRotationEnabled) {
      rotationOffset += speed * delta;
    }
    updateTransforms();
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);

  let clickStartTime = 0;
  let clickStartX = 0;
  let clickStartY = 0;

  const handleClick = (e) => {
    if (!planetSystem || isDragging) return;

    const clickedProduct = e.target.closest('.orbit-product');
    if (clickedProduct) return;

    const rect = planetSystem.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const clickX =
      e.clientX || (e.touches && e.touches[0] ? e.touches[0].clientX : null);

    if (clickX === null) return;

    const clickSide = clickX < centerX ? 1 : -1;
    const rotationAmount = ((Math.PI * 2) / total) * clickSide;
    rotationOffset += rotationAmount;

    autoRotationEnabled = false;

    setTimeout(() => {
      autoRotationEnabled = true;
    }, 2000);

    updateTransforms();
  };

  const handleMouseDown = (e) => {
    if (!planetSystem) return;
    clickStartTime = Date.now();
    clickStartX = e.clientX || e.touches[0].clientX;
    clickStartY = e.clientY || e.touches[0].clientY;
    isDragging = true;
    dragStartX = clickStartX;
    dragStartRotation = rotationOffset;
    lastDragX = dragStartX;
    lastDragTime = Date.now();
    autoRotationEnabled = false;
    e.preventDefault();
  };

  const handleMouseMove = (e) => {
    if (!isDragging || !planetSystem) return;

    const currentX =
      e.clientX || (e.touches && e.touches[0] ? e.touches[0].clientX : null);
    if (currentX === null) return;

    const now = Date.now();
    const timeDelta = now - lastDragTime;
    const xDelta = currentX - lastDragX;

    const movementSpeed = Math.abs(xDelta) / Math.max(timeDelta, 1);
    const speedMultiplier = Math.min(Math.max(movementSpeed / 2, 0.5), 3);

    const direction = xDelta > 0 ? 1 : -1;

    rotationOffset =
      dragStartRotation +
      (currentX - dragStartX) * 0.01 * direction * speedMultiplier;

    lastDragX = currentX;
    lastDragTime = now;
    e.preventDefault();
  };

  const handleMouseUp = (e) => {
    if (!isDragging) return;

    const now = Date.now();
    const timeSinceClick = now - clickStartTime;
    const moveX = Math.abs(
      (e.clientX ||
        (e.touches && e.touches[0] ? e.touches[0].clientX : clickStartX)) -
        clickStartX
    );
    const moveY = Math.abs(
      (e.clientY ||
        (e.touches && e.touches[0] ? e.touches[0].clientY : clickStartY)) -
        clickStartY
    );

    isDragging = false;

    if (timeSinceClick < 200 && moveX < 5 && moveY < 5) {
      handleClick(e);
      return;
    }

    setTimeout(() => {
      autoRotationEnabled = true;
    }, 1000);
  };

  if (planetSystem) {
    planetSystem.addEventListener('mousedown', handleMouseDown);
    planetSystem.addEventListener('touchstart', handleMouseDown, {
      passive: false,
    });

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('touchmove', handleMouseMove, { passive: false });

    document.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('touchend', handleMouseUp);

    planetSystem.addEventListener('click', handleClick);
  }
});
