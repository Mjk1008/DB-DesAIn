const audios = [];
['shemsh.mp3', 'dollar.mp3', 'rial.mp3', 'bitcoin.mp3'].forEach((audio) => {
  audios.push(new Audio(audio));
});

function fadeout(element, duration) {
  gsap.to(element, {
    duration: duration,
    opacity: 0,
  });
}

function fadein(element, duration) {
  gsap.to(element, {
    duration: duration,
    opacity: 1,
  });
}

const debug = 1;
const bg = document.querySelector('.bg');
const cta = document.querySelector('.cta');
const logo = document.querySelector('.logo');
const overline = document.querySelector('.overline');
const paragraph = document.querySelector('.paragraph');
const container = document.querySelector('.container');

const tl = gsap.timeline();
tl.to(bg, {
  delay: 1 * debug,
  duration: 1 * debug,
  transform: 'scaleX(1)',
})
  .to(paragraph, {
    opacity: 1,
    duration: 0.5 * debug,
  })
  .to(paragraph, {
    delay: 1.5 * debug,
    duration: 1 * debug,
    width: '120px',
    top: '58%',
  })
  .to(logo, {
    duration: 1 * debug,
    bottom: '96px',
  })
  .to(
    overline,
    {
      bottom: '10px',
      duration: 0.5 * debug,
    },
    '<'
  )
  .to(container, {
    opacity: 1,
    duration: 0.5 * debug,
  });

let lock = true;

logo.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK5);
});
cta.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK6);
});
const interval = setInterval(() => {
  fadeout(logo);
  fadeout(paragraph);
  fadeout(overline);
  lock = false;
  gsap.to(container, {
    bottom: '10px',
    width: '95%',
    height: '125px',
    duration: 1 * debug,
    onComplete: () => {
      gsap.to(container, {
        delay: 3 * debug,
        bottom: '35px',
        width: 'calc(100% - 165px)',
        height: '100px',
        duration: 1 * debug,
        onComplete: () => {
          lock = true;
          fadein(logo);
          fadein(paragraph);
          fadein(overline);
        },
      });
    },
  });
}, 10000);

const products = document.querySelectorAll('.product');
const lines = document.querySelectorAll('.line');

function removeTapesh() {
  products.forEach((product) => {
    product.classList.remove('tapesh');
  });
}

let first_click = true;
products.forEach((product, index) => {
  product.addEventListener('click', (e) => {
    audios[index].play();
    if (first_click) {
      if (index === 0) {
        fire_tag(ALL_EVENT_TYPES.CLICK1);
      } else if (index === 1) {
        fire_tag(ALL_EVENT_TYPES.CLICK2);
      } else if (index === 2) {
        fire_tag(ALL_EVENT_TYPES.CLICK3);
      } else if (index === 3) {
        fire_tag(ALL_EVENT_TYPES.CLICK4);
      }

      first_click = false;
      e.preventDefault();
      e.stopPropagation();
      removeTapesh();
      finalslide(index);
      clearInterval(interval);
      gsap.to(cta, {
        delay: !lock ? 3 : 0,
        opacity: 1,
      });
    }
  });
});

function finalslide(index) {
  for (let i = 0; i < lines.length; i++) {
    if (i === index) {
      gsap.to(lines[i], {
        duration: 0.2 * debug,
        height: '90%',
      });
      gsap.to(products[i], {
        duration: 0.2 * debug,
        top: '15%',
      });
      products[i].classList.add('tapesh');
    } else {
      const config = [
        {
          height: '30%',
          top: '70%',
        },
        {
          height: '20%',
          top: '80%',
        },
        {
          height: '10%',
          top: '90%',
        },
        {
          height: '20%',
          top: '80%',
        },
      ];
      gsap.to(lines[i], {
        duration: 0.2 * debug,
        height: config[i].height,
      });
      gsap.to(products[i], {
        duration: 0.2 * debug,
        top: config[i].top,
      });
    }
  }
}
