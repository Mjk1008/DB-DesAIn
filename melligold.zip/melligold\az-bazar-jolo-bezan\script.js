document.addEventListener('DOMContentLoaded', function () {
  const logo = document.querySelector('.logo');
  const cta = document.querySelector('.cta');

  const titr = document.querySelector('h1');
  const subtitr = document.querySelector('h2');
  const overline = document.querySelector('.overline');
  const product = document.querySelector('.product');

  const tl = gsap.timeline({});

  tl.to(logo, {
    delay: 0.5,
    duration: 0.5,
    transform: 'translateY(0%)',
    top: '30px',
  });

  tl.to(titr, {
    delay: 0.5,
    duration: 0.5,
    opacity: 1,
    transform: 'translateX(0em)',
  }).to(
    subtitr,
    {
      duration: 0.5,
      transform: 'translateX(0em)',
      opacity: 1,
    },
    '<'
  );

  tl.to(product, {
    duration: 0.5,
    ease: 'easeInOut',
    transform: 'translate(20%, 0%)',
    onComplete: function () {
      setTimeout(function () {
        location.reload();
      }, 1500);
    },
  });
});
