document.addEventListener('DOMContentLoaded', function () {
  const cta = document.querySelector('.cta');
  const bottomOffset = 8;
  const leftContainerOffset = -20;
  const volumeBtn = document.querySelector('.volume');
  const video = document.querySelector('.video');
  video.muted = true;
  video.play();
  cta.addEventListener('click', function () {
    fire_tag(ALL_EVENT_TYPES.CLICK1);
  });

  let float1, float2, float3;

  gsap.to('.cta', {
    scale: 1.1,
    duration: 0.5,
    ease: 'power2.inOut',
    repeat: -1,
    yoyo: true,
  });

  if (volumeBtn && video) {
    volumeBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      e.preventDefault();
      if (video.muted) {
        video.muted = false;
      } else {
        video.muted = true;
      }
    });
  }

  gsap.to('.cake1', {
    opacity: 1,
    y: bottomOffset,
    duration: 0.8,
    delay: 0.2,
    ease: 'back.out(1.7)',
    onComplete: function () {
      float1 = gsap.to('.cake1', {
        y: bottomOffset - 15,
        duration: 2,
        ease: 'sine.inOut',
        repeat: -1,
        yoyo: true,
      });
    },
  });

  gsap.to('.cake2', {
    opacity: 1,
    y: bottomOffset,
    duration: 0.8,
    delay: 0.4,
    ease: 'back.out(1.7)',
    onComplete: function () {
      float2 = gsap.to('.cake2', {
        y: bottomOffset - 15,
        duration: 2.2,
        ease: 'sine.inOut',
        repeat: -1,
        yoyo: true,
      });
    },
  });

  gsap.to('.cake3', {
    opacity: 1,
    y: bottomOffset,
    duration: 0.8,
    delay: 0.6,
    ease: 'back.out(1.7)',
    onComplete: function () {
      float3 = gsap.to('.cake3', {
        y: bottomOffset - 15,
        duration: 2.4,
        ease: 'sine.inOut',
        repeat: -1,
        yoyo: true,
      });
    },
  });

  setTimeout(function () {
    gsap.killTweensOf('.cake1');
    gsap.killTweensOf('.cake2');
    gsap.killTweensOf('.cake3');
    if (float1) float1.kill();
    if (float2) float2.kill();
    if (float3) float3.kill();

    const cake1Rect = document.querySelector('.cake1').getBoundingClientRect();
    const cake2Rect = document.querySelector('.cake2').getBoundingClientRect();
    const cake3Rect = document.querySelector('.cake3').getBoundingClientRect();
    const containerRect = document
      .querySelector('.slide1')
      .getBoundingClientRect();

    const cake1Left = cake1Rect.left - containerRect.left;
    const cake2Left = cake2Rect.left - containerRect.left;
    const cake3Left = cake3Rect.left - containerRect.left;

    gsap.set('.cake1', {
      position: 'absolute',
      left: cake1Left,
      x: 0,
      immediateRender: true,
    });
    gsap.set('.cake2', {
      position: 'absolute',
      left: cake2Left,
      x: 0,
      immediateRender: true,
    });
    gsap.set('.cake3', {
      position: 'absolute',
      left: cake3Left,
      x: 0,
      immediateRender: true,
    });

    gsap.to('.slide2', {
      opacity: 1,
      visibility: 'visible',
      duration: 0.5,
      ease: 'power2.out',
    });

    // const videoContainer = document.querySelector('.videoContainer');
    // if (video && videoContainer) {
    //   videoContainer.appendChild(video);
    //   video.play();
    // }

    gsap.to('.cake1', {
      left: leftContainerOffset + 100,
      x: 0,
      y: bottomOffset - 15,
      width: 75,
      scale: 0.85,
      zIndex: 1,
      filter: 'blur(4px)',
      duration: 1,
      ease: 'power2.out',
    });

    gsap.to('.cake2', {
      left: leftContainerOffset + 50,
      x: 0,
      width: 75,
      scale: 1.2,
      zIndex: 3,
      y: bottomOffset - 5,
      duration: 1,
      ease: 'power2.out',
    });

    gsap.to('.cake3', {
      left: leftContainerOffset + 2,
      x: 0,
      y: bottomOffset - 15,
      width: 75,
      scale: 0.85,
      zIndex: 1,
      filter: 'blur(4px)',
      duration: 1,
      ease: 'power2.out',
      onComplete: function () {
        setTimeout(function () {
          rotatePositions();
        }, 2000);
      },
    });
  }, 4000);

  function rotatePositions() {
    let tl = gsap.timeline({
      onComplete: function () {
        setTimeout(function () {
          rotatePositions2();
        }, 2000);
      },
    });

    tl.to(
      '.cake2',
      {
        left: leftContainerOffset + 102,
        x: 0,
        y: bottomOffset - 12,
        width: 75,
        scale: 0.85,
        zIndex: 1,
        filter: 'blur(4px)',
        duration: 1,
        ease: 'power2.inOut',
      },
      0
    );

    tl.to(
      '.cake3',
      {
        left: leftContainerOffset + 50,
        x: 0,
        y: bottomOffset - 4,
        width: 75,
        scale: 1.2,
        zIndex: 3,
        filter: 'blur(0px)',
        duration: 1,
        ease: 'power2.inOut',
      },
      0
    );

    tl.to(
      '.cake1',
      {
        left: leftContainerOffset + 2,
        x: 0,
        y: bottomOffset - 15,
        width: 75,
        scale: 0.85,
        zIndex: 1,
        filter: 'blur(4px)',
        duration: 1,
        ease: 'power2.inOut',
      },
      0
    );
  }
  function rotatePositions2() {
    let tl = gsap.timeline({
      onComplete: function () {
        setTimeout(function () {
          rotatePositions3();
        }, 2000);
      },
    });
    tl.to(
      '.cake1',
      {
        left: leftContainerOffset + 50,
        x: 0,
        y: bottomOffset - 4,
        width: 75,
        scale: 1.2,
        zIndex: 3,
        filter: 'blur(0px)',
        duration: 1,
        ease: 'power2.inOut',
      },
      0
    );

    tl.to(
      '.cake3',
      {
        left: leftContainerOffset + 100,
        x: 0,
        y: bottomOffset - 15,
        width: 75,
        scale: 0.85,
        zIndex: 1,
        filter: 'blur(4px)',
        duration: 1,
        ease: 'power2.inOut',
      },
      0
    );

    tl.to(
      '.cake2',
      {
        left: leftContainerOffset + 2,
        x: 0,
        y: bottomOffset - 15,
        width: 75,
        scale: 0.85,
        zIndex: 1,
        filter: 'blur(4px)',
        duration: 1,
        ease: 'power2.inOut',
      },
      0
    );
  }
  function rotatePositions3() {
    let tl = gsap.timeline({
      onComplete: function () {
        setTimeout(function () {
          rotatePositions();
        }, 2000);
      },
    });
    tl.to(
      '.cake1',
      {
        left: leftContainerOffset + 102,
        x: 0,
        y: bottomOffset - 15,
        width: 75,
        scale: 0.85,
        zIndex: 1,
        filter: 'blur(4px)',
        duration: 1,
        ease: 'power2.inOut',
      },
      0
    );

    tl.to(
      '.cake3',
      {
        left: leftContainerOffset + 2,
        x: 0,
        y: bottomOffset - 15,
        width: 75,
        scale: 0.85,
        zIndex: 1,
        filter: 'blur(4px)',
        duration: 1,
        ease: 'power2.inOut',
      },
      0
    );

    tl.to(
      '.cake2',
      {
        left: leftContainerOffset + 52,
        x: 0,
        y: bottomOffset - 4,
        width: 75,
        scale: 1.2,
        zIndex: 3,
        filter: 'blur(0)',
        duration: 1,
        ease: 'power2.inOut',
      },
      0
    );
  }
});
