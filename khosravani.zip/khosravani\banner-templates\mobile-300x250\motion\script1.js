document
  .querySelectorAll('body > *:not(.bg-video):not(.logo):not(.cta)')
  .forEach((el) => {
    el.style.display = '';
  });

window.addEventListener('load', () => {
  setTimeout(() => {
    document.body.classList.add('loaded');

    const bgVideo = document.querySelector('.bg-video');
    if (bgVideo) {
      gsap.to(bgVideo, {
        filter: 'brightness(0.4) saturate(1.2)',
        duration: 0.6,
        ease: 'power2.out',
      });
    }

    const carContainer = document.querySelector('.product');
    const pattern = document.querySelector('.pattern');
    const patternBack = document.querySelector('.patternBack');

    gsap.set([carContainer, pattern, patternBack], { opacity: 0 });
    gsap.set(carContainer, { x: '100vw' });
    gsap.set([pattern, patternBack], { x: '100vw', scale: 1 });

    const tl = gsap.timeline();

    tl.to(
      carContainer,
      {
        opacity: 1,
        x: 0,
        duration: 0.7,
        ease: 'power2.out',
        onStart: () => {
          gsap.fromTo(
            carContainer,
            { x: '100vw' },
            {
              x: 0,
              duration: 0.7,
              ease: 'power2.out',
              onComplete: () => {
                gsap.to(carContainer, {
                  x: 20,
                  duration: 1,
                  repeat: -1,
                  yoyo: true,
                  ease: 'sine.inOut',
                });

                // اگر بخواهید انیمیشن برای light2 اضافه کنید اینجا اضافه کنید
                // مثلا با تاخیر:

                // const light2 = document.querySelector('.light2');
                // gsap.fromTo(light2,
                //     { opacity: 0 },
                //     {
                //         delay: 1.5,
                //         opacity: 1,
                //         duration: 0.5,
                //         repeat: -1,
                //         yoyo: true,
                //         ease: "sine.inOut"
                //     }
                // );
              },
            }
          );
        },
      },
      0
    )

      .to(
        '.overline',
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          ease: 'power2.out',
        },
        '-=0.8'
      )

      .set('.carName', { x: 100 }, 0)
      .to(
        '.carName',
        {
          opacity: 1,
          x: 0,
          y: 0,
          duration: 0.4,
          ease: 'power2.out',
        },
        0
      )

      .set('.title', { x: 100 }, 0)
      .to(
        '.title',
        {
          opacity: 1,
          x: 0,
          y: 0,
          duration: 0.4,
          ease: 'power2.out',
        },
        0
      );

    setInterval(() => {
      location.reload();
    }, 3800);
  }, 1500);
});
