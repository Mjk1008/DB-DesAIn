const start = document.querySelector('.start');
const starttext1 = document.querySelector('.start-text1');
const starttext2 = document.querySelector('.start-text2');
const timeline = gsap.timeline({ repeat: -1, repeatDelay: 2 });
const chatBox = document.querySelector('.chat-box');
const userInput = document.querySelector('input');
const sendButton = document.querySelector('.enter');

let messageCount = 0;
const MAX_MESSAGES = 3;

timeline
  .to(start, { duration: 0.2, scale: 0.1 })
  .to(starttext1, { opacity: 0 }, '<')
  .to(starttext2, { opacity: 1 }, '<')
  .to(start, { duration: 0.2, scale: 1 })
  .to({}, { duration: 1 })
  .to(start, { duration: 0.2, scale: 0.1 })
  .to(starttext1, { opacity: 1 }, '<')
  .to(starttext2, { opacity: 0 }, '<')
  .to(start, { duration: 0.2, scale: 1 })
  .to({}, { duration: 1 });

const badges = document.querySelectorAll('.badge');

function resetStyle(el) {
  gsap.to(el, {
    duration: 0.5,
    backgroundColor: 'transparent',
    color: 'white',
    ease: 'power1.inOut',
  });
}

function highlightBadge(el) {
  gsap.to(el, {
    duration: 0.5,
    backgroundColor: 'white',
    color: '#100F0F',
    ease: 'power1.inOut',
  });
}

let currentHighlighted = null;

setInterval(() => {
  if (currentHighlighted) {
    resetStyle(currentHighlighted);
  }

  const randomIndex = Math.floor(Math.random() * badges.length);
  const badge = badges[randomIndex];

  highlightBadge(badge);
  currentHighlighted = badge;
}, 1000);

const starttexts = document.querySelectorAll('.start-text');
starttexts.forEach((text) => {
  text.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    go_to_slide2(true);
  });
});

badges.forEach((badge) => {
  badge.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    go_to_slide2(false);
    sendMessage(badge.getAttribute('data-message'));
  });
});

const tooltipContainer = document.querySelector('.tooltipContainer');
const tooltips = document.querySelectorAll('.tooltip');
const hand = document.querySelector('.hand');

function go_to_slide2(show_tooltip = false) {
  const slide1 = document.querySelector('.slide1');
  timeline.clear();

  gsap.to('.header', {
    duration: 1,
    opacity: 1,
    display: 'flex',
  });

  gsap.to('.bg2', {
    duration: 1,
    opacity: 1,
  });

  gsap.to('.chat-box', {
    duration: 1,
    opacity: 1,
    display: 'block',
  });

  if (!show_tooltip) {
    removeHandAndTooltips();
  } else {
    gsap.to(tooltipContainer, {
      duration: 1,
      opacity: 1,
      display: 'flex',
    });

    gsap.to('.hand', {
      duration: 1,
      opacity: 1,
      display: 'block',
    });

    tooltips.forEach((tooltip) => {
      tooltip.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        sendMessage(tooltip.getAttribute('data-message'));
        removeHandAndTooltips();
      });
    });
  }

  gsap.to(slide1, {
    duration: 1,
    opacity: 0,
    onComplete: () => {
      if (slide1) {
        slide1.remove();
      }
    },
  });
}

function removeHandAndTooltips() {
  if (tooltipContainer) {
    tooltipContainer.remove();
  }
  if (hand) {
    hand.remove();
  }
}

const BASE_URL = 'https://metis.uranus-agency.ir/api';
let sessionId = null;

function displayMessage(message, sender) {
  const messageElement = document.createElement('div');
  messageElement.classList.add('message', sender);

  const contentElement = document.createElement('div');
  contentElement.classList.add('message-content');
  contentElement.textContent = message;

  const profileElement = document.createElement('img');
  profileElement.classList.add('profile');
  profileElement.src = sender === 'bot' ? 'bot.svg' : 'user.svg';

  messageElement.appendChild(contentElement);
  messageElement.appendChild(profileElement);

  chatBox.appendChild(messageElement);
  chatBox.scrollTop = chatBox.scrollHeight;

  gsap.fromTo(
    messageElement,
    { opacity: 0, y: 10 },
    { opacity: 1, y: 0, duration: 0.3 }
  );

  return contentElement;
}

async function createNewSession() {
  try {
    const response = await fetch(
      `${BASE_URL}/khosravani-modiran-prod/new-session`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    sessionId = data.sessionId;
    console.log('New session created:', sessionId);
  } catch (error) {
    console.error('Error creating new session:', error);
    displayMessage(
      'خطا در برقراری ارتباط با سرور. لطفا مجددا تلاش کنید.',
      'bot'
    );
  }
}

async function sendMessage(message) {
  removeHandAndTooltips;
  if (messageCount >= MAX_MESSAGES) {
    displayMessage(
      'متاسفانه محدودیت ارسال ۳ پیام وجود دارد و بیشتر نمی‌توانید پیام بدهید.',
      'bot'
    );
    return;
  }

  messageCount++;
  displayMessage(message, 'user');
  userInput.value = '';

  if (!sessionId) {
    await createNewSession();
  }

  const botResponseElement = displayMessage('...', 'bot');
  try {
    const response = await fetch(`${BASE_URL}/send-message`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        sessionId: sessionId,
        message: message,
        stream: false,
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const response_data = await response.json();
    const botResponse = response_data.content;

    botResponseElement.textContent = botResponse;
    chatBox.scrollTop = chatBox.scrollHeight;
  } catch (error) {
    console.error('Error sending message:', error);
    botResponseElement.textContent =
      'متاسفانه در ارسال پیام مشکلی پیش آمد. لطفا دوباره تلاش کنید.';
    chatBox.scrollTop = chatBox.scrollHeight;
  }
}

// Event listeners
if (sendButton) {
  sendButton.addEventListener('click', () => {
    const message = userInput.value.trim();
    if (message) {
      sendMessage(message);
    }
  });
}

userInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    const message = userInput.value.trim();
    if (message) {
      sendMessage(message);
    }
  }
});

let first_time = true;
userInput.addEventListener('input', () => {
  if (first_time) {
    first_time = false;
    createNewSession();
  }
});
