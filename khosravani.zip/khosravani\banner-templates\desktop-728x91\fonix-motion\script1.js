document
  .querySelectorAll('body > *:not(.bg-video):not(.logo):not(.cta)')
  .forEach((el) => {
    el.style.display = '';
  });

window.addEventListener('load', () => {
  setTimeout(() => {
    document.body.classList.add('loaded');

    // const bgVideo = document.querySelector('.bg-video');
    // if (bgVideo) {
    //     gsap.to(bgVideo, {
    //         filter: 'brightness(0.4) saturate(1.2)',
    //         duration: 0.6,
    //         ease: "power2.out"
    //     });
    // }

    const carContainer = document.querySelector('.product');
    const pattern = document.querySelector('.pattern');
    const car2 = document.querySelector('.car2');
    const light2 = document.querySelector('.light2');
    const cta = document.querySelector('.cta');

    gsap.set([carContainer, car2, pattern, light2, cta], { opacity: 0 });
    gsap.set(carContainer, { x: '100vw' });
    gsap.set([car2, pattern, light2, cta], { x: '100vw', scale: 1 });

    const tl = gsap.timeline();

    tl.to(
      carContainer,
      {
        opacity: 1,
        x: 0,
        duration: 0.7,
        ease: 'power2.out',
        onStart: () => {
          gsap.fromTo(
            carContainer,
            { x: '100vw' },
            {
              x: 0,
              duration: 0.7,
              ease: 'power2.out',
              onComplete: () => {
                gsap.to(carContainer, {
                  x: 20,
                  duration: 1,
                  repeat: -1,
                  yoyo: true,
                  ease: 'sine.inOut',
                });
              },
            }
          );
        },
      },
      0
    );

    tl.to(
      pattern,
      {
        opacity: 1,
        x: 0,
        duration: 0.7,
        ease: 'power2.out',
      },
      0
    );

    tl.to(
      car2,
      {
        opacity: 1,
        x: 0,
        duration: 0.7,
        ease: 'power2.out',
      },
      0
    );

    tl.to(
      car2,
      {
        scale: 1.05,
        duration: 0.5,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
        delay: 0.2,
      },
      0.1
    );

    tl.to(
      cta,
      {
        opacity: 1,
        x: 0,
        duration: 0.7,
        ease: 'power2.out',
      },
      0
    );

    gsap.to(light2, {
      opacity: 1,
      duration: 0.5,
      repeat: -1,
      yoyo: true,
      ease: 'sine.inOut',
      delay: 0.3,
    });

    tl.to(
      '.overline',
      {
        opacity: 1,
        y: 0,
        duration: 0.5,
        ease: 'power2.out',
      },
      '-=0.8'
    );

    tl.set('.carName', { x: 100 }, 0);
    tl.to(
      '.carName',
      {
        opacity: 1,
        x: 0,
        y: 0,
        duration: 0.4,
        ease: 'power2.out',
      },
      0
    );

    tl.set('.title', { x: 100 }, 0);
    tl.to(
      '.title',
      {
        opacity: 1,
        x: 0,
        y: 0,
        duration: 0.4,
        ease: 'power2.out',
      },
      0
    );

    setInterval(() => {
      location.reload();
    }, 3800);
  }, 1500);
});
