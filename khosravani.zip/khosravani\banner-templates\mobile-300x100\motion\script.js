document
  .querySelectorAll('body > *:not(.bg-video):not(.logo):not(.cta)')
  .forEach((el) => {
    el.style.display = '';
  });
window.addEventListener('load', () => {
  setTimeout(() => {
    document.body.classList.add('loaded');

    const bgVideo = document.querySelector('.bg-video');
    if (bgVideo) {
      gsap.to(bgVideo, {
        filter: 'brightness(0.4) saturate(1.2)',
        duration: 0.6,
        ease: 'power2.out',
      });
    }

    const carContainer = document.querySelector('.product');
    const title = document.querySelector('.title');
    const carName = document.querySelector('.carName');
    const overline = document.querySelector('.overline');
    const pattern = document.querySelector('.pattern');

    gsap.set([carContainer, title, carName, overline, pattern], {
      opacity: 0,
      x: '100vw',
    });

    const tl = gsap.timeline();

    tl.to(
      carContainer,
      { opacity: 1, x: 0, duration: 0.7, ease: 'power2.out' },
      0
    )
      .to(pattern, { opacity: 1, x: 0, duration: 0.5, ease: 'power2.out' }, 0.2)
      .to(title, { opacity: 1, x: 0, duration: 0.5, ease: 'power2.out' }, 0.2)
      .to(carName, { opacity: 1, x: 0, duration: 0.5, ease: 'power2.out' }, 0.3)
      .to(
        overline,
        { opacity: 1, x: 0, duration: 0.5, ease: 'power2.out' },
        0.35
      );

    setInterval(() => {
      location.reload();
    }, 3800);
  }, 1500);
});
