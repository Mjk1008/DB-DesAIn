const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');
const suggestionButtons = document.querySelectorAll('.suggestion-item');
const notificationOverlay = document.getElementById('notification-overlay');

const numlink = document.querySelector('.num-link');

let messageCount = 0;
const MAX_MESSAGES = 3;

let hasUserInteracted = false;
let notificationInterval = null;

function showNotification() {
  if (!hasUserInteracted) {
    notificationOverlay.classList.add('show');

    setTimeout(() => {
      notificationOverlay.classList.remove('show');
    }, 3000);
  }
}

function startNotificationInterval() {
  showNotification();

  notificationInterval = setInterval(() => {
    showNotification();
  }, 5000);
}

function stopNotificationInterval() {
  if (notificationInterval) {
    clearInterval(notificationInterval);
    notificationInterval = null;
  }
  notificationOverlay.classList.remove('show');
}

function handleUserInteraction() {
  if (!hasUserInteracted) {
    hasUserInteracted = true;
    stopNotificationInterval();
  }
}

numlink.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  window.location.href = 'tel:+982161993';
  open('tel:+982161993');
  fire_tag(ACTIONS.NUMBER_TAG);
  handleUserInteraction();
});

const BASE_URL = 'https://metis.uranus-agency.ir/api';

const chat_box = document.querySelector('.chat-box');
let sessionId = null;
let isTyping = false;

function setBackgroundVideo(videoKey) {
  let existingVideo = chat_box.querySelector('video.bg-video');
  if (existingVideo) existingVideo.remove();

  const videoElement = document.createElement('video');
  videoElement.src = videos[videoKey];
  videoElement.autoplay = true;
  videoElement.loop = true;
  videoElement.muted = true;
  videoElement.playsInline = true;
  videoElement.classList.add('bg-video');
  chat_box.prepend(videoElement);
}

function removeBackgroundVideo() {
  const videoElement = document.querySelector('.chat-box video.bg-video');
  if (videoElement) {
    videoElement.remove();
  }
}

const videos = {
  arizzo5fl: 'https://khosravani.com/wp-content/uploads/2025/01/arrizo5.mp4',
  arrizo6gt: 'https://khosravani.com/wp-content/uploads/2024/12/arrizo6gt.mp4',
  arrizo6pro:
    'https://khosravani.com/wp-content/uploads/2024/12/arrizo6pro.mp4',
  arrizo8: 'https://khosravani.com/wp-content/uploads/2024/12/arrizo8.mp4',
  'fx-awd': 'https://khosravani.com/wp-content/uploads/2025/01/0109.mp4',
  'fx-ev': 'https://khosravani.com/wp-content/uploads/2025/01/EV.mp4',
  fx1600: 'https://khosravani.com/wp-content/uploads/2024/12/fx1600.mp4',
  'tiggo-7-pro-max-fwd':
    'https://khosravani.com/wp-content/uploads/2024/12/tiggo-7-pro-max-fwd.mp4',
  'tiggo7-promax-awd':
    'https://khosravani.com/wp-content/uploads/2024/12/tiggo8phev.mp4',
  tiggo8phev:
    'https://khosravani.com/wp-content/uploads/2024/12/tiggo8phev.mp4',
  tiggo8promax:
    'https://khosravani.com/wp-content/uploads/2024/12/tiggo8promax.mp4',
  txl: 'https://khosravani.com/wp-content/uploads/2024/12/txl.mp4',
  'x22-pro-mt':
    'https://khosravani.com/wp-content/uploads/2024/12/x22-pro-mt.mp4',
  'x33-cross-cvt':
    'https://khosravani.com/wp-content/uploads/2024/12/x33-cross-cvt.mp4',
  'x33cross-mt':
    'https://khosravani.com/wp-content/uploads/2024/12/x33cross-mt.mp4',
  x55pro: 'https://khosravani.com/wp-content/uploads/2024/12/x55pro.mp4',
  'xtrim-lx': 'https://khosravani.com/wp-content/uploads/2024/12/lx.mp4',
  'xtrim-vx': 'https://khosravani.com/wp-content/uploads/2024/12/VX.mp4',
};

function displayMessage(message, sender) {
  const messageElement = document.createElement('div');
  messageElement.classList.add('message', sender);
  const contentElement = document.createElement('div');
  contentElement.classList.add('message-content');
  contentElement.textContent = message;
  messageElement.appendChild(contentElement);
  chatBox.appendChild(messageElement);
  chatBox.scrollTop = chatBox.scrollHeight;
  gsap.fromTo(
    messageElement,
    { opacity: 0, y: 10 },
    { opacity: 1, y: 0, duration: 0.3 }
  );
  return contentElement;
}

async function createNewSession() {
  fire_tag(ACTIONS.CREATE_SESSION);
  try {
    const response = await fetch(
      `${BASE_URL}/khosravani-modiran-prod/new-session`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    sessionId = data.sessionId;
    console.log('New session created:', sessionId);
  } catch (error) {
    console.error('Error creating new session:', error);
    displayMessage(
      'خطا در برقراری ارتباط با سرور. لطفا مجددا تلاش کنید.',
      'bot'
    );
  }
}

async function sendMessage(message) {
  if (messageCount >= MAX_MESSAGES) {
    displayMessage(
      'متاسفانه محدودیت ارسال ۳ پیام وجود دارد و بیشتر نمی‌توانید پیام بدهید.',
      'bot'
    );
    return;
  }

  messageCount++;
  displayMessage(message, 'user');
  userInput.value = '';

  if (!sessionId) {
    await createNewSession();
  }

  const botResponseElement = displayMessage('...', 'bot');
  fire_tag(ACTIONS.SEND_MESSAGE);
  try {
    const response = await fetch(`${BASE_URL}/send-message`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        sessionId: sessionId,
        message: message,
        stream: false,
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const response_data = await response.json();
    const botResponse = response_data.content;

    botResponseElement.textContent = botResponse;
    chatBox.scrollTop = chatBox.scrollHeight;
  } catch (error) {
    console.error('Error sending message:', error);
    botResponseElement.textContent =
      'متاسفانه در ارسال پیام مشکلی پیش آمد. لطفا دوباره تلاش کنید.';
    chatBox.scrollTop = chatBox.scrollHeight;
  }
}

sendButton.addEventListener('click', () => {
  const message = userInput.value.trim();
  if (message) {
    sendMessage(message);
  }
  handleUserInteraction();
});

userInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    const message = userInput.value.trim();
    if (message) {
      sendMessage(message);
    }
    handleUserInteraction();
  }
});

let first_time = true;
userInput.addEventListener('input', () => {
  handleUserInteraction();
  if (first_time) {
    first_time = !first_time;
    createNewSession();
  }
});

suggestionButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const suggestionText = button.textContent;
    sendMessage(suggestionText);
    handleUserInteraction();
  });
});

document.addEventListener('DOMContentLoaded', () => {
  displayMessage(
    'سلام! من دستیار هوشمند خسروانی هستم و اطلاعات مربوط به ماشین‌های مدیران‌ خودرو را در اختیار شما قرار می‌دهم. اگر سوالی دارید، بفرمایید!',
    'bot'
  );
  startNotificationInterval();
});

document.body.addEventListener('click', (e) => {
  handleUserInteraction();
});

document.body.addEventListener('click', (e) => {
  const src = e.target.src;
  if (!(src && src.includes('logo'))) {
    e.preventDefault();
    e.stopPropagation();
  }
});
