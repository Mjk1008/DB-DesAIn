document.addEventListener('DOMContentLoaded', function () {
  const play = document.querySelector('.play');
  const pause = document.querySelector('.pause');
  const logo = document.querySelector('.logo');
  const logo2 = document.querySelector('.logo2');
  const overlines = document.querySelectorAll('.overline');
  const ctas = document.querySelectorAll('.cta');
  const posters = document.querySelectorAll('.poster');
  const players = document.querySelectorAll('.player');
  const video = document.querySelector('video');
  let currentIndex = 0;
  const audios = [new Audio('audio1.mp3'), new Audio('audio2.mp3')];
  let isPlaying = false;

  function toggleButton(playIt) {
    if (playIt) {
      pause.style.display = 'block';
      pause.style.opacity = '1';

      play.style.display = 'none';
      play.style.opacity = '0';
    } else {
      play.style.display = 'block';
      play.style.opacity = '1';

      pause.style.display = 'none';
      pause.style.opacity = '0';
    }
  }

  play.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    fire_tag(ALL_EVENT_TYPES.CLICK1);
    audios[currentIndex].play();
    players[currentIndex].classList.add('rotate');
    toggleButton(true);
    isPlaying = true;
  });
  pause.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    audios.forEach((audio) => {
      audio.pause();
    });
    players[currentIndex].classList.remove('rotate');
    toggleButton(false);
    isPlaying = false;
  });

  function startSlide(index) {
    play.style.display = 'block';
    gsap.to(posters[index], {
      bottom: '10px',
      duration: 1,
      onComplete: () => {
        gsap.to(logo, {
          left: '-200px',
          duration: 1,
          delay: 3,
        });
        gsap.to(video, {
          bottom: 0,
          duration: 1,
          delay: 3,
          onComplete: () => {
            video.play();
          },
        });

        gsap.to(posters[index], {
          width: '100.2px',
          left: '5%',
          bottom: '40px',
          duration: 1,
          delay: 3,
          opacity: 1,
          transform: 'translateX(0)',
          onComplete: function () {
            gsap.to(players[index], {
              marginLeft: '0',
              duration: 1,
              opacity: 1,
              onComplete: function () {
                gsap.to(ctas[index], {
                  duration: 1,
                  opacity: 1,
                });
                gsap.to(overlines[index], {
                  duration: 1,
                  opacity: 1,
                });
                gsap.to(play, {
                  duration: 1,
                  opacity: 1,
                });
                gsap.to(logo2, {
                  bottom: '118px',
                  duration: 1,
                });
                setTimeout(() => {
                  if (!isPlaying) {
                  } else {
                    setTimeout(() => {
                      stopSlide(currentIndex);
                    }, 10000);
                  }
                }, 10000);
              },
            });
          },
        });
      },
    });
  }

  function stopSlide(index) {
    gsap.to(logo, {
      duration: 1,
      left: '0',
      opacity: 1,
    });

    gsap.to(logo2, {
      duration: 1,
      bottom: '155px',
    });

    audios.forEach((audio) => {
      audio.pause();
    });
    players[currentIndex].classList.remove('rotate');
    toggleButton(false);

    gsap.to(posters[index], {
      duration: 1,
      bottom: '150px',
      onComplete: function () {
        gsap.to(posters[index], {
          transform: 'translateX(-50%)',
          left: '50%',
          width: '130px',
        });
      },
    });

    gsap.to(players[index], {
      opacity: 0,
      marginLeft: '-70px',
      duration: 0.5,
    });

    gsap.to(video, {
      duration: 1,
      bottom: '-120px',
    });

    gsap.to(overlines[index], { opacity: 0, duration: 0.5 });
    gsap.to(ctas[index], { opacity: 0, duration: 0.5 });
    gsap.to(play, { opacity: 0, duration: 0.5 });
    gsap.to(pause, { opacity: 0, duration: 0.5 });

    setTimeout(() => {
      if (index === 0) {
        startSlide(1);
        currentIndex = 1;
      } else {
        startSlide(0);
        currentIndex = 0;
      }
    }, 2000);
  }

  ctas.forEach((cta) => {
    cta.addEventListener('click', (e) => {
      fire_tag(ALL_EVENT_TYPES.CLICK2);
    });
  });

  logo.addEventListener('click', (e) => {
    fire_tag(ALL_EVENT_TYPES.CLICK3);
  });

  logo2.addEventListener('click', (e) => {
    fire_tag(ALL_EVENT_TYPES.CLICK3);
  });
  currentIndex = Math.random() < 0.5 ? 0 : 1;
  startSlide(currentIndex);
});
