const pages = document.querySelectorAll('.page');
const bgs = document.querySelectorAll('.bg');
const gap = 5;

const phone = document.querySelector('.phone-container');
const logo = document.querySelector('.logo');
const lines = document.querySelectorAll('.line');
const overlines = document.querySelectorAll('.overline');
const ctas = document.querySelectorAll('.cta');

let currentIndex = 0;
let direction = 1;

function updateCarousel() {
  const percentage = -100 * currentIndex;
  gsap.to(pages, {
    xPercent: percentage,
    x: -gap * currentIndex,
    duration: 1, // Sweep duration
    ease: 'power2.inOut',
  });
}

function nextSlide() {
  if (direction === 1) {
    if (currentIndex < pages.length - 1) {
      currentIndex++;
    } else {
      direction = -1;
      currentIndex--;
    }
  } else {
    if (currentIndex > 0) {
      currentIndex--;
    } else {
      direction = 1;
      currentIndex++;
    }
  }
  updateCarousel();
}

function fadeIn(elems, opacity = 1, duration = 1) {
  gsap.to(elems, {
    opacity: opacity,
    duration: duration,
  });
}

gsap.to(phone, {
  delay: 1,
  bottom: 0,
  duration: 1,
  onComplete: () => {
    setInterval(nextSlide, 3000);
    gsap.to(phone, {
      delay: 2,
      scale: 1.7,
      duration: 1,
      left: '25%',
      bottom: '-28%',
    });
    gsap.fromTo(
      bgs,
      {
        delay: 2,
        duration: 1,
        opacity: 0,
        transform: 'translateX(-50%) scaleX(0)',
      },
      {
        delay: 2,
        duration: 1,
        opacity: 1,
        transform: 'translateX(-50%) scaleX(1)',
      }
    );
    gsap.to(logo, {
      bottom: '114px',
      duration: 1,
      delay: 2,
      onComplete: () => {
        startSlidesInterval();
        fadeIn(lines);
        fadeIn([overlines[0]]);
        fadeIn([ctas[0]]);
      },
    });
  },
});

let current_index = 0;

function startSlidesInterval() {
  function handler() {
    const next = (current_index + 1) % bgs.length;
    console.log(current_index, next);

    function setNext(elems) {
      elems.forEach((elem, index) => {
        gsap.to(elem, {
          opacity: index === next ? 1 : 0,
          duration: 1,
        });
      });
    }

    setNext(bgs);
    setNext(overlines);
    setNext(ctas);
    setTimeout(() => {
      current_index = next;
    }, 1000);
  }

  setInterval(handler, 4000);
}
