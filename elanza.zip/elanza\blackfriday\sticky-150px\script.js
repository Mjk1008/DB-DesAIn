const logo = document.querySelector('.logo');
const cta = document.querySelector('.cta');
const stick = document.querySelector('.stick');

const products = document.querySelectorAll('.product');
let counter = 0;
gsap.to(logo, {
  duration: 1,
  bottom: '115px',
  onComplete: () => {
    gsap.to(stick, {
      opacity: 1,
      duration: 0.5,
      onComplete: () => {
        cta.classList.add('tapesh');
        gsap.to(cta, {
          opacity: 1,
          duration: 1,
          onComplete: () => {
            intervalHandler();
            setInterval(intervalHandler, 5000);
          },
        });
      },
    });
  },
});

function fadeoutall() {
  products.forEach((product) => {
    gsap.to(product, {
      bottom: '0px',
      opacity: '0',
      duration: 1,
    });
  });
}

function intervalHandler() {
  stick.classList.remove('stick-magic');
  void stick.offsetWidth;
  stick.classList.add('stick-magic');

  fadeoutall();
  if (counter === 0) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE01);
  } else if (counter === 1) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE02);
  } else if (counter === 2) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE03);
  } else if (counter === 3) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE04);
  }
  gsap.to(products[counter], {
    bottom: '70px',
    duration: 1,
    opacity: '1',
    onComplete: () => {
      counter = (counter + 1) % products.length;
    },
  });
}

cta.addEventListener('click', function () {
  fire_tag(ALL_EVENT_TYPES.CLICK1);
});

logo.addEventListener('click', function () {
  fire_tag(ALL_EVENT_TYPES.CLICK2);
});

products.forEach((product, index) => {
  product.addEventListener('click', function () {
    if (index === 0) {
      fire_tag(ALL_EVENT_TYPES.CLICK3);
    } else if (index === 1) {
      fire_tag(ALL_EVENT_TYPES.CLICK4);
    } else if (index === 2) {
      fire_tag(ALL_EVENT_TYPES.CLICK5);
    }
  });
});
