document.addEventListener('DOMContentLoaded', function () {
  if (typeof gsap === 'undefined') {
    console.error('GSAP is not loaded');
    return;
  }

  const rightContainer = document.querySelector('.rightContainer');
  const videoContainer = document.querySelector('.videoContainer');
  const video = document.querySelector('video');
  const videoSource = document.querySelector('video source');
  const gifContainer = document.querySelector('.gifContainer');
  const overline = document.querySelector('.overline');
  const cta = document.querySelector('.cta');
  const logo = document.querySelector('.logo');

  if (rightContainer) rightContainer.style.opacity = '0';
  if (gifContainer) gifContainer.style.opacity = '0';

  const bgVideos = ['./output1.mp4', './output2.mp4', './output3.mp4'];
  const productImages = ['./product1.gif', './product2.gif', './product3.gif'];
  const overlineImages = [
    './overline1.png',
    './overline3.png',
    './overline2.png',
  ];

  let currentIndex = 0;
  let allVideosLoaded = false;
  const preloadedVideos = [];
  const videoLoadPromises = [];
  function preloadAllVideos() {
    bgVideos.forEach(function (src, index) {
      const preloadVideo = document.createElement('video');
      preloadVideo.preload = 'auto';
      preloadVideo.muted = true;
      preloadVideo.playsInline = true;
      preloadVideo.setAttribute('playsinline', '');
      preloadVideo.setAttribute('webkit-playsinline', '');

      const source = document.createElement('source');
      source.src = src;
      source.type = 'video/mp4';
      preloadVideo.appendChild(source);

      const loadPromise = new Promise(function (resolve) {
        let resolved = false;

        function resolveOnce(video) {
          if (!resolved) {
            resolved = true;
            resolve(video);
          }
        }

        function checkReady() {
          if (
            preloadVideo.readyState >= 4 &&
            preloadVideo.buffered.length > 0
          ) {
            resolveOnce(preloadVideo);
          }
        }

        preloadVideo.addEventListener(
          'canplaythrough',
          function () {
            checkReady();
          },
          { once: true }
        );

        preloadVideo.addEventListener('progress', function () {
          checkReady();
        });

        preloadVideo.addEventListener('loadeddata', function () {
          checkReady();
        });

        preloadVideo.addEventListener(
          'error',
          function () {
            console.error('Error loading video:', src);
            resolveOnce(null);
          },
          { once: true }
        );

        preloadVideo.load();

        preloadVideo.addEventListener(
          'loadedmetadata',
          function () {
            if (preloadVideo.duration && preloadVideo.duration > 0) {
              preloadVideo.currentTime = Math.max(
                0,
                preloadVideo.duration - 0.5
              );

              preloadVideo.addEventListener(
                'seeked',
                function () {
                  preloadVideo.currentTime = 0;

                  setTimeout(function () {
                    if (preloadVideo.buffered.length > 0) {
                      const bufferedEnd = preloadVideo.buffered.end(
                        preloadVideo.buffered.length - 1
                      );
                      if (bufferedEnd >= preloadVideo.duration * 0.9) {
                        checkReady();
                      } else {
                        setTimeout(checkReady, 200);
                      }
                    } else {
                      checkReady();
                    }
                  }, 200);
                },
                { once: true }
              );
            } else {
              checkReady();
            }
          },
          { once: true }
        );
      });

      videoLoadPromises.push(loadPromise);
      preloadedVideos.push(preloadVideo);
    });
  }

  const product = document.createElement('img');
  product.className = 'product';
  product.src = productImages[0];
  product.style.opacity = '0';
  product.style.transform = 'scale(0.7) translateY(50px)';
  product.style.filter = 'blur(10px)';
  gifContainer.appendChild(product);

  if (overline) {
    overline.src = overlineImages[0];
    overline.style.opacity = '0';
    overline.style.transform = 'translateY(20px) scale(0.8)';
    overline.style.width = '';
    overline.style.height = '';
    overline.style.position = '';
    overline.style.bottom = '';
    overline.style.left = '';
  }

  if (logo) {
    logo.style.opacity = '0';
    logo.style.transform = 'scale(0.5) translateY(-20px)';
  }

  if (cta) {
    cta.style.opacity = '0';
    cta.style.transform = 'scale(0.5)';
  }

  if (video) {
    video.style.opacity = '0';
    video.style.transform = 'scale(0.9)';
  }

  preloadAllVideos();
  Promise.all(videoLoadPromises).then(function (loadedVideos) {
    allVideosLoaded = true;

    const firstPreloadedVideo = preloadedVideos[0];
    if (firstPreloadedVideo && firstPreloadedVideo.readyState >= 4) {
      const firstSource = firstPreloadedVideo.querySelector('source');
      if (firstSource) {
        videoSource.src = firstSource.src;
        video.load();
      } else {
        videoSource.src = bgVideos[0];
        video.load();
      }
    } else {
      videoSource.src = bgVideos[0];
      video.load();
    }

    function startFirstVideo() {
      if (video.readyState >= 4) {
        video.currentTime = 0;
        video.play().catch(function (err) {
          console.log('Video play error:', err);
        });

        if (rightContainer) {
          gsap.to(rightContainer, {
            opacity: 1,
            duration: 0.3,
            ease: 'power2.out',
          });
        }
        if (gifContainer) {
          gsap.to(gifContainer, {
            opacity: 1,
            duration: 0.3,
            ease: 'power2.out',
          });
        }

        const initialTl = gsap.timeline();

        initialTl.to(
          video,
          {
            opacity: 1,
            scale: 1,
            duration: 1,
            ease: 'power2.out',
          },
          0
        );

        if (logo) {
          initialTl.to(
            logo,
            {
              opacity: 1,
              scale: 1,
              y: 0,
              duration: 0.8,
              ease: 'back.out(1.7)',
            },
            0.2
          );
        }

        initialTl.to(
          product,
          {
            opacity: 1,
            scale: 1,
            y: 0,
            filter: 'blur(0px)',
            duration: 1.2,
            ease: 'back.out(1.4)',
          },
          0.3
        );

        if (overline) {
          initialTl.to(
            overline,
            {
              opacity: 1,
              scale: 1,
              y: 0,
              duration: 0.8,
              ease: 'power2.out',
            },
            0.5
          );
        }

        if (cta) {
          initialTl
            .to(
              cta,
              {
                opacity: 1,
                scale: 1,
                duration: 0.8,
                ease: 'back.out(2)',
              },
              0.6
            )
            .to(
              cta,
              {
                scale: 1.15,
                duration: 1.2,
                ease: 'power1.inOut',
                yoyo: true,
                repeat: -1,
              },
              1.2
            );
        }
      } else {
        setTimeout(startFirstVideo, 100);
      }
    }

    video.addEventListener(
      'canplaythrough',
      function () {
        startFirstVideo();
      },
      { once: true }
    );
    if (video.readyState >= 4) {
      startFirstVideo();
    }
  });

  function switchToNext() {
    if (!allVideosLoaded) return;

    currentIndex = (currentIndex + 1) % bgVideos.length;

    const currentVideo = document.querySelector('video');

    const newVideo = document.createElement('video');
    newVideo.autoplay = true;
    newVideo.muted = true;
    newVideo.playsInline = true;
    newVideo.loop = true;
    newVideo.preload = 'auto';
    newVideo.setAttribute('playsinline', '');
    newVideo.setAttribute('webkit-playsinline', '');

    const preloadedVideo = preloadedVideos[currentIndex];
    if (preloadedVideo && preloadedVideo.readyState >= 4) {
      const preloadedSource = preloadedVideo.querySelector('source');
      if (preloadedSource) {
        const newSource = document.createElement('source');
        newSource.src = preloadedSource.src;
        newSource.type = preloadedSource.type;
        newVideo.appendChild(newSource);
      } else {
        const newSource = document.createElement('source');
        newSource.src = bgVideos[currentIndex];
        newSource.type = 'video/mp4';
        newVideo.appendChild(newSource);
      }
    } else {
      const newSource = document.createElement('source');
      newSource.src = bgVideos[currentIndex];
      newSource.type = 'video/mp4';
      newVideo.appendChild(newSource);
    }

    newVideo.style.opacity = '0';
    newVideo.style.width = '100%';
    newVideo.style.height = '100%';
    newVideo.style.objectFit = 'cover';
    newVideo.style.pointerEvents = 'none';
    newVideo.style.position = 'absolute';
    newVideo.style.top = '0';
    newVideo.style.left = '0';

    videoContainer.appendChild(newVideo);

    function startTransition() {
      newVideo.currentTime = 0;
      newVideo.play().catch(function (err) {
        console.log('Video play error:', err);
      });

      const tl = gsap.timeline({
        onComplete: function () {
          currentVideo.pause();
          currentVideo.remove();
          newVideo.style.width = '';
          newVideo.style.height = '';
          newVideo.style.objectFit = '';
          newVideo.style.pointerEvents = '';
          newVideo.style.position = '';
          newVideo.style.top = '';
          newVideo.style.left = '';
        },
      });

      tl.to(
        currentVideo,
        {
          opacity: 0,
          duration: 0.5,
          ease: 'power2.in',
        },
        0
      ).to(
        newVideo,
        {
          opacity: 1,
          duration: 0.6,
          ease: 'power2.out',
        },
        0.2
      );
    }

    newVideo.load();

    if (newVideo.readyState >= 4) {
      startTransition();
    } else {
      newVideo.addEventListener(
        'canplaythrough',
        function () {
          startTransition();
        },
        { once: true }
      );

      newVideo.addEventListener(
        'loadeddata',
        function () {
          if (newVideo.readyState >= 3) {
            setTimeout(function () {
              if (newVideo.readyState >= 3) {
                startTransition();
              }
            }, 100);
          }
        },
        { once: true }
      );
    }

    const currentProduct = document.querySelector('.product');
    const nextProductSrc = productImages[currentIndex];

    const currentRect = currentProduct.getBoundingClientRect();
    const containerRect = gifContainer.getBoundingClientRect();
    const relativeLeft = currentRect.left - containerRect.left;
    const relativeTop = currentRect.top - containerRect.top;
    gsap.set(currentProduct, {
      position: 'absolute',
      left: relativeLeft + 'px',
      top: relativeTop + 'px',
    });

    const newProduct = document.createElement('img');
    newProduct.className = 'product';
    newProduct.src = nextProductSrc;
    newProduct.style.position = 'absolute';
    newProduct.style.left = relativeLeft + 'px';
    newProduct.style.top = relativeTop + 'px';
    newProduct.style.opacity = '0';
    newProduct.style.filter = 'blur(8px)';
    newProduct.style.transform = 'scale(0.8) rotate(-5deg)';

    gifContainer.appendChild(newProduct);

    const productTl = gsap.timeline({
      onComplete: function () {
        currentProduct.remove();
        gsap.set(newProduct, {
          position: '',
          left: '',
          top: '',
          filter: '',
          transform: '',
        });
      },
    });

    productTl
      .to(
        currentProduct,
        {
          opacity: 0,
          scale: 0.7,
          y: -30,
          rotation: 8,
          filter: 'blur(6px)',
          duration: 0.5,
          ease: 'power2.in',
        },
        0
      )
      .to(
        newProduct,
        {
          opacity: 1,
          scale: 1,
          rotation: 0,
          filter: 'blur(0px)',
          duration: 0.8,
          ease: 'power2.out',
        },
        0.2
      );

    if (overline) {
      const currentOverline = overline;
      const nextOverlineSrc = overlineImages[currentIndex];

      const newOverline = document.createElement('img');
      newOverline.className = 'overline';
      newOverline.src = nextOverlineSrc;
      newOverline.style.opacity = '0';
      newOverline.style.filter = 'blur(8px)';
      newOverline.style.transform = 'scale(0.9)';

      videoContainer.appendChild(newOverline);

      const overlineTl = gsap.timeline({
        onComplete: function () {
          currentOverline.remove();
          newOverline.style.filter = '';
          newOverline.style.transform = '';
        },
      });

      overlineTl
        .to(
          currentOverline,
          {
            opacity: 0,
            scale: 0.8,
            filter: 'blur(6px)',
            duration: 0.5,
            ease: 'power2.in',
          },
          0
        )
        .to(
          newOverline,
          {
            opacity: 1,
            scale: 1,
            filter: 'blur(0px)',
            duration: 0.8,
            ease: 'power2.out',
          },
          0.2
        );
    }
  }

  function startSwitching() {
    if (!allVideosLoaded) {
      setTimeout(startSwitching, 100);
      return;
    }

    setInterval(function () {
      switchToNext();
    }, 5000);
  }

  startSwitching();
});
