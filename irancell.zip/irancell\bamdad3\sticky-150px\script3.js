const overline = document.querySelector('.overline');
const cta = document.querySelector('.cta');
const bg = document.querySelectorAll('.bg');
const logo = document.querySelector('.logo');
const unmute = document.querySelector('.unmute');
let isMute = true;
const tl = gsap.timeline({});

unmute.addEventListener('click', (e) => {
  console.log(e);
  e.preventDefault();
  e.stopPropagation();
  bg[1].muted = !isMute;
  isMute = !isMute;
});

gsap.to(bg[1], {
  duration: 1,
  delay: 1,
  transform: 'scaleX(1)',
  onComplete: () => {
    bg[1].play();
    gsap.to(unmute, { opacity: 1, duration: 0.5 });

    tl.fromTo(
      overline,
      {
        opacity: 0,
        duration: 1,
        right: '-200px',
      },
      {
        opacity: 1,
        duration: 1,
        right: '10%',
        onComplete: () => {
          gsap.to(logo, {
            opacity: 1,
            duration: 1,
          });
          gsap.to(cta, {
            opacity: 1,
            duration: 1,
          });

          // setTimeout(() => {
          //     location.reload();
          // }, 10000);
        },
      }
    );
  },
});
gsap.to(bg[0], {
  duration: 1,
  delay: 1,
  transform: 'scaleX(1)',
});
