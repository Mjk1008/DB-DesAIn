const phone = document.querySelector('.phone');
const overline = document.querySelector('.overline');
const cta = document.querySelector('.cta');
const bg = document.querySelector('.bg');
const logo = document.querySelector('.logo');

const tl = gsap.timeline({});

tl.to(bg, {
  delay: 1,
  bottom: '5px',
  opacity: 1,
});

tl.to(phone, {
  duration: 1,
  bottom: '42px',
  onComplete: () => {
    gsap.fromTo(
      overline,
      {
        transform: 'scaleX(0)',
        duration: 1,
        opacity: 0,
      },
      {
        transform: 'scaleX(1)',
        opacity: 1,
        onComplete: () => {
          gsap.to(logo, {
            opacity: 1,
            duration: 1,
          });
          gsap.to(cta, {
            opacity: 1,
            duration: 1,
          });

          setTimeout(() => {
            location.reload();
          }, 10000);
        },
      }
    );
  },
});
