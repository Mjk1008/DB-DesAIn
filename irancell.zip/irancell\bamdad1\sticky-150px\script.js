const person = document.querySelector('.person');
const overline = document.querySelector('.overline');
const cta = document.querySelector('.cta');
const bg = document.querySelector('.bg');
const logo = document.querySelector('.logo');

const tl = gsap.timeline({});

tl.to(bg, {
  duration: 1,
  delay: 1,
  transform: 'scaleX(1)',
});

tl.to(person, {
  duration: 1,
  bottom: 0,
  ease: 'Power2.easeOut',
  onComplete: () => {
    gsap.fromTo(
      overline,
      {
        opacity: 0,
        duration: 1,
        right: '-200px',
      },
      {
        opacity: 1,
        duration: 1,
        right: '5%',
        onComplete: () => {
          gsap.to(logo, {
            opacity: 1,
            duration: 1,
          });
          gsap.to(cta, {
            opacity: 1,
            duration: 1,
          });

          setTimeout(() => {
            location.reload();
          }, 10000);
        },
      }
    );
  },
});
