document.addEventListener('DOMContentLoaded', function () {
  const bgContainer = document.querySelector('.bg-container');
  const leftCurtain = document.querySelector('.leftcurtain');
  const rightCurtain = document.querySelector('.rightcurtain');
  const logo = document.querySelector('.logo');
  const bgVideo = document.querySelector('.bg-video');
  const bgImage = document.querySelector('.bg-image');
  const slide3 = document.querySelector('.slide3');
  const right = document.querySelector('.right');
  const left = document.querySelector('.left');

  bgVideo.muted = true;
  bgVideo.play();

  let mainTimeline = null;
  let videoEndListener = null;

  function initAnimation() {
    if (mainTimeline) {
      mainTimeline.kill();
    }

    const tl = gsap.timeline();
    mainTimeline = tl;

    bgVideo.load();

    gsap.set(bgContainer, { y: '100%' });
    gsap.set(logo, {
      opacity: 0,
      scale: 1,
      y: 0,
      rotation: 0,
      filter: 'none',
      display: 'block',
    });
    gsap.set(leftCurtain, { x: 0, transformOrigin: 'center' });
    gsap.set(rightCurtain, { x: 0, transformOrigin: 'center' });
    gsap.set(bgImage, { opacity: 1, scale: 1, filter: 'none' });
    gsap.set(bgVideo, {
      x: 0,
      y: 0,
      scale: 1,
      filter: 'none',
      opacity: 1,
      display: 'block',
    });
    gsap.set(slide3, { opacity: 0, pointerEvents: 'none' });
    gsap.set(right, { opacity: 0, x: 50 });
    gsap.set(left, { opacity: 0, x: -50 });

    tl.to(bgContainer, {
      y: 0,
      duration: 0.6,
      ease: 'power2.out',
    });

    tl.to(logo, {
      opacity: 1,
      duration: 1.5,
      ease: 'power2.out',
    });

    tl.to(
      leftCurtain,
      {
        x: '-150%',
        duration: 1.2,
        ease: 'power2.in',
        transformOrigin: 'center',
      },
      0.8
    );

    tl.to(
      rightCurtain,
      {
        x: '150%',
        duration: 1.2,
        ease: 'power2.in',
        transformOrigin: 'center',
      },
      0.8
    );

    tl.call(
      function () {
        gsap.set(bgImage, { opacity: 0 });

        videoEndListener = function onVideoEnd() {
          setTimeout(function () {
            const overline = document.querySelector('.overline');
            const cta = document.querySelector('.cta');

            cta.addEventListener('click', function () {
              fire_tag(ALL_EVENT_TYPES.CLICK1);
            });

            const endTimeline = gsap.timeline();

            gsap.set(slide3, {
              opacity: 1,
              pointerEvents: 'auto',
              onComplete: function () {
                gsap.to(bgVideo, {
                  duration: 2,
                  filter: 'brightness(0.5)',
                  onComplete: function () {
                    bgVideo.loop = true;
                    bgVideo.currentTime = 0;
                    bgVideo.play();
                  },
                });
              },
            });

            endTimeline.to(
              right,
              {
                opacity: 1,
                x: 0,
                duration: 0.7,
                ease: 'power3.out',
              },
              '-=0.1'
            );

            endTimeline.fromTo(
              overline,
              { opacity: 0, y: -15, scale: 0.9 },
              {
                opacity: 1,
                y: 0,
                scale: 1,
                duration: 0.5,
                ease: 'back.out(1.2)',
              },
              '-=0.5'
            );

            endTimeline.fromTo(
              cta,
              { opacity: 0, scale: 0.5, rotation: -10 },
              {
                opacity: 1,
                scale: 1,
                rotation: 0,
                duration: 0.6,
                ease: 'back.out(1.4)',
              },
              '-=0.3'
            );

            endTimeline.to(
              left,
              {
                opacity: 1,
                x: 0,
                duration: 0.7,
                ease: 'power3.out',
              },
              '-=0.4'
            );

            bgVideo.removeEventListener('ended', videoEndListener);
          }, 1000);
        };

        bgVideo.addEventListener('ended', videoEndListener);
      },
      null,
      0.8
    );
  }

  function stopAllAnimations() {
    if (mainTimeline) {
      mainTimeline.kill();
    }

    gsap.killTweensOf([
      bgContainer,
      logo,
      leftCurtain,
      rightCurtain,
      bgImage,
      bgVideo,
      slide3,
      right,
      left,
    ]);
  }

  function startLoop() {
    stopAllAnimations();
    initAnimation();
    fire_tag(ALL_EVENT_TYPES.LOOP);
  }

  initAnimation();

  setTimeout(function () {
    startLoop();

    setInterval(function () {
      startLoop();
    }, 28000);
  }, 28000);

  setTimeout(function () {
    location.reload();
  }, 60000);
});
