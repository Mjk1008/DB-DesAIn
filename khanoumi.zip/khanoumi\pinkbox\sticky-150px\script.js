const cta = document.querySelector('.cta');
const bottomFront = document.querySelector('.bottom-front');
const bottomBack = document.querySelector('.bottom-back');
const box = document.querySelector('.box');
const logo = document.querySelector('.logo');
const product1 = document.querySelector('.product1');
const product2 = document.querySelector('.product2');
const subheader = document.querySelector('.haraj-roozane');
const header = document.querySelector('.jabe-soorati');
const bg = document.querySelector('.bg');

const debug = 1;

const tl = gsap.timeline({});

tl.to(bg, {
  transform: 'scaleX(1)',
  duration: 1 * debug,
  onComplete: () => {
    gsap.to(bottomBack, {
      bottom: '0',
      duration: 1.5 * debug,
    });
    gsap.to(bottomFront, {
      bottom: '0',
      duration: 1.5 * debug,
    });
  },
});

tl.to(logo, {
  top: '0',
  duration: 1 * debug,
  delay: 2 * debug,
  onComplete: () => {
    gsap.to(product1, { delay: 1, bottom: '90px', duration: 1 * debug });
    gsap.to(product2, { delay: 1, bottom: '100px', duration: 1 * debug });
  },
})
  .to(box, {
    bottom: '25px',
    duration: 1.5 * debug,
  })
  .to(header, {
    transform: 'scaleX(1)',
    duration: 1 * debug,
  })
  .to(subheader, {
    transform: 'scaleX(1)',
    duration: 1 * debug,
  })
  .to(cta, {
    opacity: 1,
    duration: 1 * debug,
    onComplete: final,
  });

function final() {
  setTimeout(() => {
    document.querySelector('.snow3').remove();
    gsap.to(logo, { top: '-50px', duration: 1 * debug });
    gsap.to(bg, { bottom: '-150px', duration: 1 * debug });
    gsap.to(bottomBack, { bottom: '-65px', duration: 1 * debug });
    gsap.to(bottomFront, { bottom: '-65px', duration: 1 * debug });
    gsap.to(header, { right: '-200px', duration: 1 * debug });
    gsap.to(subheader, { right: '-200px', duration: 1 * debug });
    gsap.to(cta, { opacity: 0, duration: 1 * debug });
    gsap.to(box, {
      left: '50%',
      width: '150px',
      bottom: '10px',
      transform: 'translateX(-50%)',
      duration: 1 * debug,
    });
    gsap.to(product1, {
      left: '42%',
      bottom: '80px',
      height: '60px',
      transform: 'translateX(-50%)',
      duration: 1 * debug,
    });
    gsap.to(product2, {
      left: '50%',
      height: '50px',
      bottom: '75px',
      transform: 'translateX(-50%)',
      duration: 1 * debug,
    });

    setTimeout(() => {
      gsap.to(box, { duration: 0, opacity: 0 });
      gsap.to(product1, { duration: 0, opacity: 0 });
      gsap.to(product2, { duration: 0, opacity: 0 });
      setTimeout(() => {
        location.reload();
      }, 1000);
    }, 5000);
  }, 10000 * debug);
}
