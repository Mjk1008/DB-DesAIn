document.addEventListener('DOMContentLoaded', function () {
  const bag = document.querySelector('.bag');
  const percent = document.querySelector('.percent');
  const bg = document.querySelector('.bg');
  const snapp = document.querySelector('.logo');
  const logo = document.querySelector('.snapp');
  const overline = document.querySelector('.overline');
  const cta = document.querySelector('.cta');
  let interval = null;

  bag.addEventListener('click', function () {
    fire_tag(ALL_EVENT_TYPES.CLICK1);
  });
  percent.addEventListener('click', function () {
    fire_tag(ALL_EVENT_TYPES.CLICK2);
  });
  logo.addEventListener('click', function () {
    fire_tag(ALL_EVENT_TYPES.CLICK3);
  });
  cta.addEventListener('click', function () {
    fire_tag(ALL_EVENT_TYPES.CLICK4);
  });
  snapp.addEventListener('click', function () {
    fire_tag(ALL_EVENT_TYPES.CLICK5);
  });
});
