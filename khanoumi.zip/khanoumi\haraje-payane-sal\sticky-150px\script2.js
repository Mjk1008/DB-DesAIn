document.addEventListener('DOMContentLoaded', () => {
  // return;
  const bgElements = document.querySelectorAll('.bg');
  let bgIndex = 0;

  bgElements.forEach((bg, index) => {
    if (index === 0) {
      gsap.set(bg, { opacity: 1 });
    } else {
      gsap.set(bg, { opacity: 0 });
    }
  });

  setInterval(() => {
    gsap.to(bgElements[bgIndex], {
      opacity: 0,
      duration: 0.5,
    });

    bgIndex = (bgIndex + 1) % bgElements.length;

    gsap.to(bgElements[bgIndex], {
      opacity: 1,
      duration: 0.5,
    });
  }, 4000);

  const productElements = document.querySelectorAll('.product');
  let productIndex = 0;

  productElements.forEach((product, index) => {
    if (index === 0) {
      gsap.set(product, { opacity: 1, top: 0 });
    } else {
      gsap.set(product, { opacity: 0, top: -300 });
    }
  });

  setInterval(() => {
    gsap.to(productElements[productIndex], {
      opacity: 0,
      top: 300,
      duration: 0.6,
      onComplete: () => {
        productIndex = (productIndex + 1) % productElements.length;
        gsap.to(productElements[productIndex], {
          opacity: 0,
          top: -300,
          duration: 0,
          onComplete: () => {
            gsap.to(productElements[productIndex], {
              opacity: 1,
              top: 0,
              duration: 0.6,
            });
          },
        });
      },
    });
  }, 4000);
});
