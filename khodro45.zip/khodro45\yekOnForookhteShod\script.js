const changancontainer = document.querySelector('.changan-container');
const minicar = document.querySelector('.minicar');

const titrs = document.querySelectorAll('.titr');
const bgs = document.querySelectorAll('.bg');
const ctas = document.querySelectorAll('.cta');

const drift = document.querySelector('.drift');
const logo = document.querySelector('.logo');
const subtitr = document.querySelector('.subtitr');
const changan = document.querySelector('.changan');
const road = document.querySelector('.road');

let state = false;

function drift_it() {
  const DURATION = 3;
  const DELAY = 1;

  gsap.to(changancontainer, {
    duration: DURATION,
    rotate: '-10deg',
    delay: DELAY,
  });

  gsap.to(changan, {
    duration: DURATION,
    rotate: '0deg',
    delay: DELAY,
  });
}

function _toggle() {
  function fade(elem, opacity) {
    gsap.to(elem, {
      duration: 1,
      opacity: opacity,
    });
  }

  if (state) {
    fade(titrs[0], 1);
    fade(titrs[1], 0);
    fade(bgs[0], 1);
    fade(bgs[1], 0);
    fade(ctas[0], 1);
    fade(ctas[1], 0);
  } else {
    fade(titrs[0], 0);
    fade(titrs[1], 1);
    fade(bgs[0], 0);
    fade(bgs[1], 1);
    fade(ctas[0], 0);
    fade(ctas[1], 1);
  }
  state = !state;
}

setTimeout(() => {
  gsap.to(logo, {
    left: 0,
    delay: 1,
    duration: 2,
  });

  gsap.to(bgs[1], {
    left: 0,
    duration: 2.7,
    onComplete: init,
  });
}, 1500);

function init() {
  _toggle();
  gsap.to(changan, {
    duration: 1,
    opacity: 1,
  });
  gsap.to(drift, {
    duration: 1,
    opacity: 1,
  });
  gsap.to(road, {
    duration: 1,
    opacity: 1,
  });
  gsap.to(minicar, {
    duration: 1,
    opacity: 1,
  });
  gsap.to(subtitr, {
    delay: 1,
    duration: 1,
    opacity: 1,
  });
  setTimeout(() => {
    startminicar();
    drift_it();
    startcolorinterval();
  }, 1000);
}

function startminicar() {
  function buff() {
    gsap.to(minicar, {
      duration: 3,
      delay: 1,
      left: '250px',
      onComplete: () => {
        gsap.fromTo(
          minicar,
          {
            left: '-20px',
            opacity: 0,
            duration: 1,
          },
          { opacity: 1, duration: 1 }
        );
      },
    });
  }

  setInterval(buff, 5000);
  buff();
}

let interval = null;

function startcolorinterval() {
  interval = setInterval(_toggle, 3000);
  setTimeout(finishloop, 26_000);
}

function finishloop() {
  clearInterval(interval);
  [...titrs, subtitr, ...ctas, road, minicar, changan, drift].forEach((el) => {
    gsap.to(el, {
      opacity: 0,
      duration: 1,
    });
  });

  gsap.to(logo, {
    left: '-150px',
    duration: 2,
  });

  gsap.to(bgs[1], {
    left: '-100%',
    delay: 0.3,
    duration: 2,
  });

  setTimeout(() => {
    location.reload();
  }, 2.5 * 1000);
}

ctas.forEach((cta) => {
  cta.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK1);
  });
});
