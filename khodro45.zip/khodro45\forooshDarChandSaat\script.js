const road = document.querySelector('.road-container');
const cars = document.querySelectorAll('.car');
const bgs = document.querySelectorAll('.bg');
const overlines = document.querySelectorAll('.overline');
const ctas = document.querySelectorAll('.cta');
const logo = document.querySelector('.logo');

gsap.to(cars[0], {
  top: '100%',
  duration: 3,
  onComplete: () => {
    start_car1();
  },
});

gsap.to(cars[1], {
  top: '100%',
  duration: 3,
  delay: 1.5,
  onComplete: () => {
    start_car2();
  },
});

function start_car1() {
  gsap.set(cars[0], {
    top: 0,
  });
  gsap.to(cars[0], {
    top: '100%',
    duration: 3,
    onComplete: () => {
      start_car1();
    },
  });
}

function start_car2() {
  gsap.set(cars[1], {
    top: 0,
  });
  gsap.to(cars[1], {
    top: '100%',
    duration: 3,
    onComplete: () => {
      start_car2();
    },
  });
}

setTimeout(() => {
  gsap.to(road, {
    left: 'unset',
    right: '110px',
    top: '-15%',
    duration: 2,
  });
  gsap.to(bgs[0], {
    duration: 1,
    delay: 2.5,
    transform: 'scaleX(1)',
  });
  gsap.set(bgs[1], {
    transform: 'scaleX(1)',
    opacity: 0,
  });
  gsap.to(logo, {
    duration: 1,
    delay: 2,
    right: 0,
    onComplete: () => {
      gsap.to(overlines[0], {
        opacity: 1,
        duration: 1,
        onComplete: () => {
          ctas.forEach((cta) => {
            cta.classList.add('tapesh');
          });
        },
      });
      gsap.to(ctas[0], {
        opacity: 1,
        duration: 1,
        onComplete: startColorLoop,
      });
    },
  });
}, 7000);

let flag = 0;

function startColorLoop() {
  function handler(elems) {
    const opac0 = flag === 0 ? 0 : 1;
    const opac1 = flag === 0 ? 1 : 0;
    gsap.to(elems[0], {
      duration: 1,
      opacity: opac0,
    });
    gsap.to(elems[1], {
      duration: 1,
      opacity: opac1,
    });
  }

  handler(bgs);
  handler(ctas);
  handler(overlines);

  setInterval(() => {
    flag = flag === 0 ? 1 : 0;
    handler(bgs);
    handler(ctas);
    handler(overlines);
  }, 5000);
}
