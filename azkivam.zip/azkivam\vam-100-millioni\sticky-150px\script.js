document.addEventListener('DOMContentLoaded', function () {
  const man = document.querySelector('.man');
  const man2 = document.querySelector('.man2');
  const hundred = document.querySelector('.hundred');
  const cloud = document.querySelector('.cloud');
  const bg = document.querySelector('.bg');
  const logo = document.querySelector('.logo');
  const overline = document.querySelector('.overline');
  const cta = document.querySelector('.cta');

  let colorbg = true;

  gsap.to(hundred, {
    right: '8%',
    duration: 1,
    onComplete: function () {
      man.src = `${man.src}`;
      man.style.opacity = 1;
      gsap.to(man, {
        left: '-15%',
        duration: 1.5,
      });
      gsap.to(cloud, {
        scale: 1,
        duration: 0.5,
        delay: 1,
      });
      setTimeout(function () {
        const duration = 1;
        gsap.to(man, { opacity: 0, duration: duration });
        gsap.to(hundred, { left: '30px', right: 'unset', duration: duration });
        gsap.to(cloud, { opacity: 0, duration: duration });
        goToSlide2();
      }, 7000);
    },
  });

  function goToSlide2() {
    gsap.to(man2, {
      left: '10px',
      duration: 1,
    });

    gsap.to(bg, {
      right: '5px',
      duration: 1,
      onComplete: function () {
        gsap.to(overline, {
          opacity: 1,
          duration: 1,
        });
        gsap.to(cta, {
          opacity: 1,
          duration: 1,
          onComplete: startInterval,
        });
      },
    });

    gsap.to(logo, {
      top: '0px',
      duration: 1,
    });
  }

  hundred.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK1);
  });

  man.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK2);
  });
  cta.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK3);
  });
  logo.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK4);
  });
  man2.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK5);
  });

  function startInterval() {
    function handler() {
      const next = colorbg
        ? 'linear-gradient(-45deg, #0A64BE, #6DA4DC)'
        : 'linear-gradient(-45deg, #1B189E, #0077FB)';
      colorbg = !colorbg;
      gsap.to(bg, {
        background: next,
        duration: 1,
      });
    }

    setTimeout(() => {
      fire_tag(ALL_EVENT_TYPES.LOOP);
      location.reload();
    }, 30000);

    handler();
    setInterval(handler, 3000);
  }
});
