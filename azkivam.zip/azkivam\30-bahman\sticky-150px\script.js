document.addEventListener('DOMContentLoaded', function () {
  const bgs = document.querySelectorAll('.bg');
  const cta = document.querySelector('.cta');
  const logo = document.querySelector('.logo');
  const overline = document.querySelector('.overline');
  const bahman = document.querySelector('.bahman');
  const car = document.querySelector('.car-container');
  const wheels = car.querySelectorAll('.wheel');
  const numBGS = document.querySelectorAll('.numbg');
  const titles = document.querySelectorAll('.title');
  const nums = document.querySelectorAll('.num');
  const dots = document.querySelectorAll('.dots');

  gsap.to(bgs[0], {
    duration: 2,
    right: '7.5px',
    onComplete: function () {
      startBGInterval();
      startCar();

      fadein(cta, 1);
      fadein(bahman, 1);
      gsap.to(overline, {
        opacity: 1,
        transform: 'scaleX(1)',
        duration: 1,
        delay: 0.5,
      });
      fadein(logo, 0);
      startTimer();
    },
  });
  gsap.to(bgs[1], {
    duration: 2,
    right: '7.5px',
  });

  function fadein(el, delay) {
    gsap.to(el, { opacity: 1, duration: 1, delay: delay });
  }

  function startTimer() {
    const daynum = document.querySelector('.daynum');
    const hournum = document.querySelector('.hournum');
    const minutenum = document.querySelector('.minutenum');
    const secondnum = document.querySelector('.secondnum');

    [...titles, ...nums, ...numBGS, ...dots].forEach((el) => {
      fadein(el, 0);
    });

    const targetDate = new Date('2026-02-19T23:59:59');

    const toPersianNumber = (num) =>
      num.toString().replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);

    function updateTimer() {
      const now = new Date();
      const diff = targetDate - now;

      if (diff <= 0) {
        daynum.textContent = '۰۰';
        hournum.textContent = '۰۰';
        minutenum.textContent = '۰۰';
        secondnum.textContent = '۰۰';
        return;
      }

      const totalSeconds = Math.floor(diff / 1000);
      const days = Math.floor(totalSeconds / 86400);
      const hours = Math.floor((totalSeconds % 86400) / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;

      daynum.textContent = toPersianNumber(String(days).padStart(2, '0'));
      hournum.textContent = toPersianNumber(String(hours).padStart(2, '0'));
      minutenum.textContent = toPersianNumber(String(minutes).padStart(2, '0'));
      secondnum.textContent = toPersianNumber(String(seconds).padStart(2, '0'));
    }

    updateTimer();
    setInterval(updateTimer, 1000);
  }

  let flag = true;

  function startBGInterval() {
    const bg2 = document.querySelector('.bg2');

    function handler() {
      gsap.to(bg2, {
        duration: 1,
        opacity: flag ? 0 : 1,
      });
      flag = !flag;
    }

    handler();
    setInterval(handler, 5000);
  }

  function startCar() {
    gsap.to(car, {
      left: '5px',
      duration: 2,
      onComplete: function () {
        stopWheels();
        startCarLoop();
      },
    });
    let IS_IN = true;

    function startCarLoop() {
      function handler() {
        startWheels(IS_IN);
        const left = IS_IN ? '-50px' : '5px';
        gsap.to(car, {
          duration: 1,
          left: left,
          onComplete: stopWheels,
        });
        IS_IN = !IS_IN;
      }

      setInterval(handler, 2000);
    }
  }

  function stopWheels() {
    wheels.forEach(function (wheel, i) {
      if (wheel.classList.contains('rotate')) {
        wheel.classList.remove('rotate');
      }
      if (wheel.classList.contains('rotateback')) {
        wheel.classList.remove('rotateback');
      }
    });
  }

  function startWheels(is_back) {
    wheels.forEach(function (wheel, i) {
      wheel.classList.add(is_back ? 'rotateback' : 'rotate');
    });
  }

  car.addEventListener('click', function (event) {
    fire_tag(ALL_EVENT_TYPES.CLICK1);
  });

  cta.addEventListener('click', function (event) {
    fire_tag(ALL_EVENT_TYPES.CLICK2);
  });

  bahman.addEventListener('click', function (event) {
    fire_tag(ALL_EVENT_TYPES.CLICK3);
  });
});
