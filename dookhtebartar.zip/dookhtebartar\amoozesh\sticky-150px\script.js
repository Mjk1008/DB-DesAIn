const contentElement = document.querySelector('.content');
const contentScrollHeight = contentElement.scrollHeight;
const itemsCount = Math.round(contentScrollHeight / 100);
let currentSlideNumber = 0;
const cards = document.querySelectorAll('.card');
let currentCardIndex = 0;
const bgContainer = document.querySelector('.bgContainer');
const logo = document.querySelector('.logo');
const video = document.querySelector('.video');
const card = document.querySelector('.card');
const copy = document.querySelector('.copy');
const gift = document.querySelector('.gift');
const gift2 = document.querySelector('.gift2');
const cta = document.querySelector('.cta');
const unmuteButton = document.querySelector('.unmuteButton');

cards.forEach((card, index) => {
  card.addEventListener('click', () => {
    if (index === 0) {
      fire_tag(ALL_EVENT_TYPES.CLICK3);
    } else if (index === 1) {
      fire_tag(ALL_EVENT_TYPES.CLICK4);
    } else if (index === 2) {
      fire_tag(ALL_EVENT_TYPES.CLICK5);
    }
  });

  if (index !== 0) {
    card.style.opacity = '0';
  }
});

cta.addEventListener('click', (event) => {
  fire_tag(ALL_EVENT_TYPES.CLICK1);
});

function startAnimations() {
  gsap.to([bgContainer, logo, video, cta], {
    duration: 1,
    opacity: 1,
    ease: 'power2.out',
    onComplete: () => {
      gsap.fromTo(
        card,
        { x: 200, opacity: 0 },
        {
          duration: 0.8,
          x: 0,
          opacity: 1,
          ease: 'back.out(1.5)',
          onComplete: () => {
            gsap.to(copy, {
              duration: 0.6,
              opacity: 1,
              ease: 'power2.out',
              onComplete: () => {
                gsap.fromTo(
                  [gift, gift2],
                  { scale: 0, opacity: 0 },
                  {
                    duration: 0.5,
                    scale: 1.2,
                    opacity: 1,
                    ease: 'back.out(2)',
                    onComplete: () => {
                      gsap.to([gift, gift2], {
                        duration: 0.3,
                        scale: 1,
                        ease: 'power2.out',
                      });
                    },
                  }
                );
              },
            });
          },
        }
      );
    },
  });
}

window.addEventListener('load', startAnimations);

function changeCard(nextNumber) {
  const currentCard = cards[currentCardIndex];
  const nextCard = cards[nextNumber];

  gsap.to(currentCard, {
    duration: 0.5,
    opacity: 0,
  });
  gsap.to(nextCard, {
    duration: 0.5,
    opacity: 1,
  });

  currentCardIndex = nextNumber;
}

function handleBackground(currentNumber, NextNumber) {
  if (NextNumber === 0) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE01);
  } else if (NextNumber === 1) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE02);
  } else if (NextNumber === 2) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE03);
  }

  changeCard(NextNumber);
}

function handleScroll(percent, scrollPx, heightOfPage) {
  const withPercent = heightOfPage < 3500;
  let newSlideNumber = withPercent
    ? Math.round((percent / 100) * (itemsCount - 1))
    : Math.trunc(scrollPx / 700);

  newSlideNumber %= cards.length;

  if (newSlideNumber === currentSlideNumber) {
    return;
  }
  handleBackground(currentSlideNumber, newSlideNumber);
  currentSlideNumber = newSlideNumber;
}

window.addEventListener('scroll', () => {
  const scrollPercent =
    (window.scrollY /
      (document.documentElement.scrollHeight - window.innerHeight)) *
    100;
  const scrollPx = window.scrollY;
  const heightOfPage = document.documentElement.scrollHeight;
  handleScroll(scrollPercent, scrollPx, heightOfPage);
});

function toggleSound() {
  video.muted = !video.muted;
}

unmuteButton.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  toggleSound();
  fire_tag(ALL_EVENT_TYPES.CLICK2);
});

window.addEventListener('message', (e) => {
  if (e.data.type !== 'yn-window-scroll') {
    return;
  }
  handleScroll(e.data.scrolled, e.data.scrolledInPx, e.data.heightOfPage);
});
