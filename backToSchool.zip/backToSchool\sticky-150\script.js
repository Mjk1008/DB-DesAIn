const contentElement = document.querySelector('.content');
const contentScrollHeight = contentElement.scrollHeight;
const itemsCount = Math.round(contentScrollHeight / 100);
const leftContainer = document.querySelector('.leftContainer');
let currentSlideNumber = 0;
const products = document.querySelectorAll('.product');
setTimeout(() => {
  document.querySelector('.floatRight').classList.add('swing');
}, 500);

const imageCache = {};
let overline = document.querySelector('.overline');
const rightContainer = document.querySelector('.overlineConntainer');
const overlines = [
  './overline1-1.png',
  './overline2-1.png',
  './overline3.png',
  './overline4.png',
  './overline5.png',
  './overline6.png',
];

(function init() {
  products.forEach((value, key) => {
    if (key !== 0) {
      value.style.opacity = '0';
    }
  });
  overlines.forEach(async (url, index) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const urlObject = URL.createObjectURL(blob);
      const img = document.createElement('img');
      img.src = urlObject;
      img.classList.add('overline');
      fire_tag(ACTIONS.VISIT_PRODUCT[0]);
      imageCache[url] = img;
    } catch (error) {
      console.error('Error loading overline:', error);
    }
  });
})();

function changeOverlineSrc(url) {
  overline.remove();
  overline = imageCache[url];
  overline.style.opacity = 0;
  rightContainer.appendChild(overline);
}

function changeOverline(nextNumber) {
  gsap.to(overline, {
    duration: 0.5,
    opacity: 0,
    onComplete: () => {
      changeOverlineSrc(overlines[nextNumber]);
      gsap.to(overline, {
        duration: 0.5,
        opacity: 1,
      });
    },
  });
}

function handleBackground(currentNumber, NextNumber) {
  console.log(NextNumber);
  changeOverline(NextNumber);
  fire_tag(ACTIONS.VISIT_PRODUCT[NextNumber]);

  gsap.to(products[currentNumber % products.length], {
    duration: 0.7,
    opacity: 0,
  });
  gsap.to(products[NextNumber], {
    duration: 0.7,
    opacity: 1,
  });
}

function handleScroll(percent, scrollPx, heightOfPage) {
  const withPercent = heightOfPage < 3500;
  let newSlideNumber = withPercent
    ? Math.round((percent / 100) * (itemsCount - 1))
    : Math.trunc(scrollPx / 700);

  // if (newSlideNumber >= itemsCount) {
  //     newSlideNumber =
  //         newSlideNumber - itemsCount * Math.trunc(newSlideNumber / itemsCount);
  // }
  newSlideNumber %= products.length;
  if (newSlideNumber === currentSlideNumber) {
    return;
  }
  handleBackground(currentSlideNumber, newSlideNumber);
  currentSlideNumber = newSlideNumber;
}

window.addEventListener('message', (e) => {
  if (e.data.type !== 'yn-window-scroll') {
    return;
  }
  handleScroll(e.data.scrolled, e.data.scrolledInPx, e.data.heightOfPage);
});

document.querySelector('.logoContainer').addEventListener('click', () => {
  fire_tag(ACTIONS.CLICK_LOGO);
});

products.forEach((product, key) => {
  product.addEventListener('click', () => {
    fire_tag(ACTIONS.CLICK_PRODUCT);
    console.log('product');
  });
});
