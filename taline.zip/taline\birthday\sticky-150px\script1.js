const cta = document.querySelector('.cta');
cta.addEventListener('click', function (e) {
  fire_tag(ALL_EVENT_TYPES.CLICK1);
});

var tl = gsap.timeline();

tl.to(
  '.cardsContainer',
  {
    left: 28,
    duration: 1.8,
    ease: 'none',
  },
  0.3
);

tl.to(
  '.goldCard1',
  {
    left: -100,
    duration: 1.8,
    ease: 'none',
  },
  0.3
);

tl.to(
  '.cardsContainer',
  {
    left: '50%',
    bottom: '8px',
    rotate: 40,
    duration: 1,
    ease: 'power2.out',
    onComplete: function () {
      gsap.to('.goldCard1', {
        opacity: 0,
        duration: 0.8,
        ease: 'power2.in',
      });
    },
  },
  2.1
);

tl.to(
  '.bg',
  {
    opacity: 1,
    width: '95%',
    duration: 1.2,
    ease: 'power2.out',
  },
  3.1
);

tl.fromTo(
  '.overline',
  {
    opacity: 0,
    y: 20,
    scale: 0.8,
  },
  {
    opacity: 1,
    y: 0,
    scale: 1,
    duration: 0.7,
    ease: 'back.out(1.7)',
  },
  4.3
);

tl.fromTo(
  '.cta',
  {
    opacity: 0,
    y: 15,
    scale: 0.9,
  },
  {
    opacity: 1,
    y: 0,
    scale: 1,
    duration: 0.7,
    ease: 'back.out(1.7)',
    onComplete: function () {
      gsap.to('.cta', {
        scale: 1.1,
        duration: 0.8,
        ease: 'power1.inOut',
        yoyo: true,
        repeat: -1,
      });
    },
  },
  4.5
);

tl.fromTo(
  '.logo',
  {
    opacity: 0,
    y: 15,
    scale: 0.9,
  },
  {
    opacity: 1,
    y: 0,
    scale: 1,
    duration: 0.7,
    ease: 'back.out(1.7)',
  },
  4.7
);

tl.fromTo(
  '.years',
  {
    opacity: 0,
    y: -20,
    scale: 0.8,
    rotation: -10,
  },
  {
    opacity: 1,
    y: 0,
    scale: 1,
    rotation: 0,
    duration: 0.8,
    ease: 'elastic.out(1, 0.5)',
  },
  4.9
);

tl.fromTo(
  '.papers',
  {
    opacity: 0,
    scale: 0.7,
    x: 30,
  },
  {
    opacity: 1,
    scale: 1,
    x: 0,
    duration: 0.8,
    ease: 'power3.out',
    onComplete: function () {
      gsap.to('.papers', {
        y: -15,
        rotation: 2,
        duration: 2.5,
        ease: 'sine.inOut',
        yoyo: true,
        repeat: -1,
      });
    },
  },
  5.2
);

// ========== SLIDE3 ANIMATIONS COMMENTED OUT ==========
/*
tl.to(
  '.goldCard1',
  {
    opacity: 0,
    scale: 0.8,
    duration: 0.6,
    ease: 'power2.in',
  },
  10.8
); // Fade out goldCard1 before slide3

tl.to(
  '.cardsContainer',
  {
    opacity: 0,
    scale: 0.8,
    duration: 0.6,
    ease: 'power2.in',
  },
  10.8
); // Fade out cardsContainer before slide3

tl.to(
  '.left',
  {
    opacity: 0,
    scale: 0.9,
    duration: 0.6,
    ease: 'power2.in',
  },
  10.8
); // Fade out left container (includes all left elements) before slide3

tl.fromTo(
  '.golds',
  {
    opacity: 0,
    scale: 0.6,
    x: -40,
    rotation: -15,
  },
  {
    opacity: 1,
    scale: 1,
    x: 0,
    rotation: 0,
    duration: 0.8,
    ease: 'back.out(1.7)',
  },
  11.0
); // First: golds (slides in from right with rotation)

tl.fromTo(
  '.cards',
  {
    opacity: 0,
    scale: 0.7,
    y: 20,
    rotation: 10,
  },
  {
    opacity: 1,
    scale: 1,
    y: 0,
    rotation: 0,
    duration: 0.8,
    ease: 'elastic.out(1, 0.5)',
  },
  11.3
); // Second: cards (0.3s after golds, with bounce)

tl.fromTo(
  '.lastPapers',
  {
    opacity: 0,
    scale: 0.5,
    y: -30,
    rotation: -20,
  },
  {
    opacity: 1,
    scale: 1,
    y: 0,
    rotation: 0,
    duration: 0.9,
    ease: 'back.out(2)',
  },
  11.6
); // Third: lastPapers (0.3s after cards, with strong bounce)

tl.fromTo(
  '.cta2',
  {
    opacity: 0,
    scale: 0.8,
    y: 15,
    x: -20,
  },
  {
    opacity: 1,
    scale: 1,
    y: 0,
    x: 0,
    duration: 0.7,
    ease: 'power3.out',
    onComplete: function () {
      // Start pulse animation for cta2
      gsap.to('.cta2', {
        scale: 1.1,
        duration: 0.8,
        ease: 'power1.inOut',
        yoyo: true,
        repeat: -1,
      });
    },
  },
  11.9
); // Fourth: cta2 (0.3s after lastPapers)

tl.fromTo(
  '.logo2',
  {
    opacity: 0,
    scale: 0.8,
    y: 15,
    x: 20,
  },
  {
    opacity: 1,
    scale: 1,
    y: 0,
    x: 0,
    duration: 0.7,
    ease: 'power3.out',
  },
  12.2
); // Fifth: logo2 (0.3s after cta2)

tl.fromTo(
  '.overline2',
  {
    opacity: 0,
    scale: 0.7,
    y: 25,
    x: -15,
  },
  {
    opacity: 1,
    scale: 1,
    y: 0,
    x: 0,
    duration: 0.8,
    ease: 'back.out(1.5)',
  },
  12.5
); // Sixth: overline2 (0.3s after logo2)

tl.fromTo(
  '.paper',
  {
    opacity: 0,
    scale: 0.3,
    y: -40,
    rotation: -45,
    x: -10,
  },
  {
    opacity: 1,
    scale: 1,
    y: 0,
    rotation: 0,
    x: 0,
    duration: 1.0,
    ease: 'elastic.out(1, 0.6)',
  },
  12.8
); // Last: paper (0.3s after overline2, with strong elastic bounce)
*/
// ========== END OF SLIDE3 ANIMATIONS ==========

// Reload page after 15 seconds to loop
setTimeout(function () {
  window.location.reload();
  fire_tag(ALL_EVENT_TYPES.LOOP);
}, 15000);
