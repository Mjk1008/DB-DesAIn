document.addEventListener('DOMContentLoaded', function () {
  const titr = document.querySelector('h1');
  const subtitr = document.querySelector('h2');

  function animate() {
    const tl = gsap.timeline({
      repeat: -1,
      repeatDelay: 6.12,
    });

    tl.fromTo(
      titr,
      {
        opacity: 0,
        x: '5em',
      },
      {
        delay: 1,
        duration: 0.5,
        opacity: 1,
        x: '-1.5em',
        ease: 'power2.out',
      }
    );

    tl.fromTo(
      subtitr,
      {
        opacity: 0,
        x: '5em',
      },
      {
        duration: 0.5,
        x: '-2em',
        opacity: 1,
        ease: 'power2.out',
      }
    );
  }

  animate();
});
