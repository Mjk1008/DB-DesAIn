document.addEventListener('DOMContentLoaded', function () {
  const logo = document.querySelector('.logo');
  const cta = document.querySelector('.cta');

  const titr = document.querySelector('h1');
  const subtitr = document.querySelector('h2');
  const overline = document.querySelector('.overline');
  const product = document.querySelector('.product');

  function animate() {
    const tl = gsap.timeline({});

    tl.fromTo(
      titr,
      {
        duration: 0.5,
        opacity: 0,
        transform: 'translateX(2em)',
      },
      {
        delay: 1,
        duration: 0.5,
        opacity: 1,
        transform: 'translateX(0em)',
      }
    );

    tl.fromTo(
      subtitr,
      {
        duration: 0.5,
        opacity: 0,
        transform: 'translateX(2em)',
      },
      {
        duration: 0.5,
        transform: 'translateX(0em)',
        opacity: 1,
        onComplete: function () {
          setTimeout(function () {
            animate();
          }, 2000);
        },
      }
    );
  }

  animate();
});
