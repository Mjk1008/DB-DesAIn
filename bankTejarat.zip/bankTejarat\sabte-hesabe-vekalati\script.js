const contentElement = document.querySelector('.content');
const contentScrollHeight = contentElement.scrollHeight;
const itemsCount = Math.round(contentScrollHeight / 150) + 1;
let currentSlideNumber = 0;
const products = document.querySelectorAll('.product');
const videoContainer = document.querySelector('.videoContainer');

(function init() {
  products.forEach((value, key) => {
    if (key !== 0) {
      value.style.opacity = '0';
    }
  });
})();

function handleProduct(currentNumber, NextNumber) {
  console.log(NextNumber);
  gsap.to(products[currentNumber % products.length], {
    duration: 0.7,
    opacity: 0,
  });
  gsap.to(products[NextNumber], {
    duration: 0.7,
    opacity: 1,
  });
}

function handleScroll(percent, scrollPx, heightOfPage) {
  const withPercent = heightOfPage < 3500;
  let newSlideNumber = withPercent
    ? Math.round((percent / 300) * (itemsCount - 1))
    : Math.trunc(scrollPx / 700);

  newSlideNumber %= products.length;
  if (newSlideNumber === currentSlideNumber) {
    return;
  }
  handleProduct(currentSlideNumber, newSlideNumber);
  currentSlideNumber = newSlideNumber;
}

window.addEventListener('message', (e) => {
  if (e.data.type !== 'yn-window-scroll') {
    return;
  }
  handleScroll(e.data.scrolled, e.data.scrolledInPx, e.data.heightOfPage);
});



const video = document.getElementById('videoBox');
function toggleSound() {
  unmuteButton.style.opacity = video.muted ? '1' : '0.5'
  video.muted = !video.muted;
}


const unmuteButton = document.querySelector('.unmuteButton');
unmuteButton.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  toggleSound();
  fire_tag(ALL_EVENT_TYPES.CLICK4);
});


gsap.to(videoContainer, {
  duration: 1,
  bottom: "5px",
  onComplete: () => {
    videoContainer.querySelector('video').play();
  },
});
