const baloon = document.querySelector('.baloon');
const audio = new Audio('badkonak.mp3');
baloon.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  fire_tag(ALL_EVENT_TYPES.CLICK1);
  audio.play();
  TNT_element(baloon);
});

function TNT_element(element) {
  element.style.pointerEvents = 'none';
  gsap.to(element, {
    scale: 1.5,
    opacity: 0,
    duration: 0.5,
    ease: 'power2.out',
  });
  const particleCount = 100;
  for (let i = 0; i < particleCount; i++) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    document.body.appendChild(particle);
    const rect = element.getBoundingClientRect();
    gsap.set(particle, {
      position: 'absolute',
      top: rect.top + rect.height / 2,
      left: rect.left + rect.width / 2,
      width: 2,
      height: 2,
      backgroundColor: '#1fbdb6',
      borderRadius: '50%',
      pointerEvents: 'none',
    });

    gsap.to(particle, {
      x: (Math.random() - 0.5) * 200,
      y: (Math.random() - 0.5) * 200,
      opacity: 0,
      scale: 0.5,
      duration: 1,
      ease: 'power2.out',
      onComplete: () => {
        particle.remove();
      },
    });
  }
}

const bazpardakht = document.querySelector('.bazpardakht span');
const mablagh = document.querySelector('.mablagh span');

function formatPersianNumbers(str) {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

  function formatNumber(numStr) {
    const withCommas = numStr.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return withCommas.replace(/\d/g, (d) => persianDigits[d]);
  }

  return str.replace(/\d+/g, (match) => formatNumber(match));
}

function handleInputChanges(element, isFirstTime = false) {
  if (!isFirstTime) {
    fire_tag(ALL_EVENT_TYPES.CLICK2);
  }
  let value = 0;
  if (element) {
    value = element.value;
  } else {
    value = 200000000;
  }

  const rounded = Math.round(value / 60 / 1000) * 1000;
  bazpardakht.innerText = formatPersianNumbers(rounded.toString());
  mablagh.innerText = formatPersianNumbers(`${value}`);
}

handleInputChanges(null, true);

document.querySelector('.tag').addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK3);
});
