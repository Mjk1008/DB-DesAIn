window.addEventListener('load', () => {
  const slider = document.getElementById('balanceSlider');
  const currentAmount = document.getElementById('currentAmount');
  const maxAmount = document.getElementById('maxAmount');
  const container = document.querySelector('.container');
  const slide1 = document.querySelector('.slide1');
  const banner1 = document.querySelector('.banner1');
  const loanButton = document.querySelector('.loan-button');
  const range = document.querySelector('.slider-container');
  const lottieContainer = document.getElementById('lottie-container');

  const gradients = [
    'linear-gradient(135deg, #4472c4, #2c5aa0)',
    'linear-gradient(135deg, #A220BB, #C945E3)',
    'linear-gradient(135deg, #05AA7F, #5DCDB7)',
    'linear-gradient(135deg, #F8AA00, #DAB100)',
    'linear-gradient(135deg, #FA616C, #D52935)',
  ];

  const buttonTextColors = ['#4472c4', '#A220BB', '#05AA7F', '#000', '#FA616C'];

  const cardJsonUrls = [
    'json1.json',
    'json2.json',
    'json3.json',
    'json4.json',
    'json5.json',
  ];

  const randomIndex = Math.floor(Math.random() * gradients.length);

  if (slider) {
    slider.style.display = 'block';
    slider.style.visibility = 'visible';
    slider.style.opacity = '1';
  }

  if (banner1) banner1.style.backgroundImage = gradients[randomIndex];
  if (container) container.style.backgroundImage = gradients[randomIndex];
  if (loanButton) loanButton.style.color = buttonTextColors[randomIndex];

  if (randomIndex === 3) {
    document.body.classList.add('black-text-mode');

    document
      .querySelectorAll('*')
      .forEach((el) => el.style.setProperty('color', '#000', 'important'));

    if (banner1) banner1.style.setProperty('color', '#000', 'important');
    if (container) container.style.setProperty('color', '#000', 'important');

    ['main-text', 'sub-text'].forEach((cls) => {
      const el = banner1.querySelector('.' + cls);
      if (el) el.style.setProperty('color', '#000', 'important');
    });

    ['header-text', 'max-amount', 'text-above-container'].forEach((cls) => {
      const el = container.querySelector('.' + cls);
      if (el) el.style.setProperty('color', '#000', 'important');
    });

    document
      .querySelectorAll('.card-text')
      .forEach((el) => el.style.setProperty('color', '#000', 'important'));
  }

  lottieAnimation = lottie.loadAnimation({
    container: lottieContainer,
    renderer: 'svg',
    loop: false,
    autoplay: false,
    path: cardJsonUrls[randomIndex],
  });

  lottieAnimation.addEventListener('DOMLoaded', () => {
    const startFrame = 35;
    const totalFrames = lottieAnimation.totalFrames;
    const stopFrame = totalFrames - 10;
    let stopped = false;

    const playFromFrame = (animation, start, end) => {
      animation.playSegments([start, end], true);
    };

    playFromFrame(lottieAnimation, startFrame, totalFrames);

    lottieAnimation.addEventListener('enterFrame', (e) => {
      if (!stopped && e.currentTime >= stopFrame) {
        stopped = true;
        lottieAnimation.pause();
      }
    });
  });

  function formatNumber(num) {
    return num.toLocaleString('fa-IR');
  }

  function updateAmount() {
    const value = parseInt(slider.value);
    maxAmount.textContent = formatNumber(value) + ' ریال';
    currentAmount.textContent = formatNumber(Math.floor(value / 10)) + ' ریال';
  }
  let cardClicked = false;
  const timer = setTimeout(() => {
    if (!cardClicked) {
      if (slide1) {
        gsap.to(slide1, {
          y: '100%',
          opacity: 0,
          duration: 0.7,
          ease: 'power1.in',
          onComplete: () => {
            if (lottieAnimation) {
              lottieAnimation.puse();
            }
          },
        });
      }
      if (container) {
        gsap.to(container, {
          opacity: 1,
          y: 0,
          duration: 0.7,
          ease: 'power1.out',
        });
      }
      slider.addEventListener('input', () => {
        updateAmount();
      });
    }
  }, 4000);

  if (range) {
    range.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
    });
  }
});
