const car = document.querySelector('.carContainer');
const X = document.querySelector('.X');
const bg = document.querySelector('.bg');
const overline = document.querySelector('.overline');
const overline2 = document.querySelector('.overline2');
const logo = document.querySelector('.logo');
const logo2 = document.querySelector('.logo2');
const road = document.querySelector('.road');
const progress = document.querySelector('.progress');
const miniCar = document.querySelector('.miniCar');
const countOverline = document.querySelector('.countOverline');
const countText = document.querySelector('.countText');
const cta = document.querySelector('.cta');

const tl = gsap.timeline({});

tl.to(X, {
  bottom: '5px',
  duration: 1,
});

tl.to(car, {
  left: '-50px',
  duration: 1,
  ease: 'back.out(1.2)',
  onComplete: () => {
    gsap.to(X, {
      left: '20px',
      delay: 1,
      duration: 1,
      transform: 'translateX(0px)',
    });

    gsap.to(bg, {
      right: '10px',
      delay: 1,
      duration: 1,
    });

    setTimeout(goToSlide2, 8000);
  },
});

function goToSlide2() {
  gsap.to(bg, {
    width: 'calc(100% - 20px)',
    duration: 1,
    background:
      'linear-gradient(130deg, rgb(64, 241, 149) -70%, rgb(17, 17, 17) 40%)',
  });
  gsap.to(X, {
    scale: '0.5',
    duration: 1,
    bottom: '20px',
    left: '0px',
  });

  gsap.to(logo, {
    duration: 1,
    opacity: 0,
  });
  gsap.to(overline, {
    duration: 1,
    opacity: 0,
  });

  setTimeout(() => {
    gsap.to(logo2, {
      duration: 1,
      bottom: 'initial',
      top: '0',
      opacity: 1,
    });
    gsap.to(road, {
      opacity: 1,
      duration: 1,
    });
    gsap.to(miniCar, {
      opacity: 1,
      duration: 1,
    });
    gsap.to(progress, {
      opacity: 1,
      duration: 1,
    });
    gsap.to(countOverline, {
      opacity: 1,
      duration: 1,
    });
    gsap.to(countText, {
      opacity: 1,
      duration: 1,
    });
    gsap.to(cta, {
      opacity: 1,
      duration: 1,
    });
    gsap.to(overline2, {
      opacity: 1,
      duration: 1,
    });

    setTimeout(goToSlide3, 1000);
  }, 1000);
}

function goToSlide3() {
  gsap.to(miniCar, {
    left: '50%',
    duration: 2,
  });
  gsap.to(progress, {
    duration: 2,
    width: '50%',
  });
  countUp('505723');
  setTimeout(() => {
    gsap.to('.bg', {
      duration: 1.5,
      bottom: '-150px',
    });
    gsap.to('.logo2', {
      duration: 1.5,
      top: '-100px',
    });
    gsap.to('.X', {
      duration: 1.5,
      bottom: '-150px',
      onComplete: () => {
        location.reload();
      },
    });
  }, 12000);

  setTimeout(() => {
    gsap.to(car, {
      left: '-70px',
      ease: 'linear',
      duration: 1,
      yoyo: true,
      repeat: -1,
    });
  }, 2000);
}

function toPersianNumber(num) {
  return num
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, '،')
    .replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);
}

function countUp(count) {
  const duration = 2000;
  const startTime = performance.now();

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const currentValue = Math.floor(progress * count);

    countText.innerText = toPersianNumber(currentValue);

    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }

  requestAnimationFrame(update);
}
