const gardooneContainer = document.querySelector('.gardooneContainer');
const gardoone = gardooneContainer.querySelector('.gardoone');
const overline1 = document.querySelector('.overline1');
const overline2 = document.querySelector('.overline2');
const cta = document.querySelector('.cta');
const logo = document.querySelector('.logo');

gsap.to(gardooneContainer, {
  bottom: '5px',
  duration: 1,
  onComplete: () => {
    setTimeout(() => {
      gardoone.classList.add('charkhesh');
      slide2();
    }, 2000);
  },
});

function slide2() {
  gsap.to(gardooneContainer, {
    left: '25%',
    duration: 1,
    delay: 1,
    onComplete: () => {
      gsap.to('.bg', {
        duration: 1,
        transform: 'scaleX(1)',
        onComplete: () => {
          gsap.to(overline1, {
            duration: 1,
            opacity: 1,
            delay: 0.2,
          });
          gsap.to(logo, {
            duration: 1,
            top: '0',
            opacity: 1,
          });
          flag = !flag;
          setInterval(startOverlines, 5000);
          gsap.to(cta, {
            opacity: 1,
            duration: 1,
          });
        },
      });
    },
  });
}

let flag = true;

function startOverlines() {
  gsap.to(overline2, {
    opacity: flag ? 0 : 1,
    duration: 1,
  });
  gsap.to(overline1, {
    opacity: flag ? 1 : 0,
    duration: 1,
  });
}

gardooneContainer.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK1);
});

cta.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK2);
});

logo.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK3);
});
