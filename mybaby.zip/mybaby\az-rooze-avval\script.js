document.addEventListener('DOMContentLoaded', function () {
  const cta = document.querySelector('.cta');

  const titr = document.querySelector('h1');
  const subtitr = document.querySelector('h2');
  const overline = document.querySelector('.overline');
  const product = document.querySelector('.product');

  const tl = gsap.timeline({});

  function motion() {
    product.style.transform = `translate(120%, 0%)`;
    titr.style.opacity = 0;
    subtitr.style.opacity = 0;
    titr.style.transform = `translateX(5em)`;
    subtitr.style.transform = `translateX(5em)`;

    gsap.fromTo(
      product,
      {
        transform: 'translate(120%, 0%)',
      },
      {
        delay: 0.5,
        duration: 0.5,
        ease: 'easeInOut',
        transform: 'translate(0%, 0%)',
        onComplete: function () {
          gsap.fromTo(
            titr,
            {
              transform: 'translateX(5em)',
            },
            {
              duration: 0.5,
              opacity: 1,
              transform: 'translateX(0em)',
            }
          );

          gsap.fromTo(
            subtitr,
            {
              transform: 'translateX(5em)',
            },
            {
              duration: 0.5,
              transform: 'translateX(0em)',
              opacity: 1,
              onComplete: function () {
                setTimeout(function () {
                  motion();
                }, 1500);
              },
            },
            '<'
          );
        },
      }
    );
  }

  motion();
});
