document.addEventListener('DOMContentLoaded', () => {
  const logoContainer = document.querySelector('.logoContainer');
  const audio = new Audio('output.mp3');
  const cta = document.querySelector('.cta');
  const flipdownElement = document.querySelector('.flipdown');

  function TNT_element(element) {
    audio.play();
    fire_tag(ALL_EVENT_TYPES.CLICK1);
    element.style.pointerEvents = 'none';
    console.log(element.style.height);
    gsap.to(element, {
      scale: 1.5,
      opacity: 0,
      duration: 0.5,
      ease: 'power2.out',
    });
    const particleCount = 100;
    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      document.body.appendChild(particle);
      const rect = element.getBoundingClientRect();
      gsap.set(particle, {
        position: 'absolute',
        top: rect.top + rect.height / 2,
        left: rect.left + rect.width / 2,
        width: 2,
        height: 2,
        backgroundColor: '#f8931e',
        borderRadius: '50%',
        pointerEvents: 'none',
      });

      gsap.to(particle, {
        x: (Math.random() - 0.5) * 200,
        y: (Math.random() - 0.5) * 200,
        opacity: 0,
        scale: 0.5,
        duration: 1,
        ease: 'power2.out',
        onComplete: () => {
          particle.remove();
        },
      });
    }
  }

  function getSecondsUntilTimestamp(timestamp) {
    const now = new Date();
    const targetDate = new Date(timestamp);
    const timeDifference = targetDate.getTime() - now.getTime();
    const secondsRemaining = Math.floor(timeDifference / 1000);
    return secondsRemaining >= 0 ? secondsRemaining : 0;
  }

  function animate(ghatre) {
    randomDelay = Math.random() * 2000;
    randomDurationTolerance = Math.random() * 2000;
    gsap.to(ghatre, {
      ease: 'linear',
      duration: 2.5 + randomDurationTolerance / 1000,
      delay: randomDelay / 1000,
      bottom: -100,
      onComplete: () => {
        gsap.set(ghatre, {
          bottom: '150px',
        });
        animate(ghatre);
      },
    });
  }

  const ghatres = document.querySelectorAll('.ghatre');
  ghatres.forEach((ghatre) => {
    ghatre.addEventListener(
      'click',
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        TNT_element(ghatre);
      },
      { once: true }
    );
    animate(ghatre);
  });
  setTimeout(() => {
    fire_tag(ALL_EVENT_TYPES.AUTOPLAY1);
    ghatres.forEach((ghatre) => {
      gsap.to(ghatre, {
        opacity: 0,
        duration: 1,
        onComplete: () => {
          ghatre.remove();
        },
      });
    });
    gsap.to('#slide2', {
      delay: 1,
      duration: 0.5,
      opacity: 1,
      onComplete: () => {
        cta.classList.add('tapesh');
        come_header();
      },
    });
    gsap.to(logoContainer, {
      duration: 1,
      justifyContent: 'center',
      background: 'white',
      border: '2px solid var(--sepah-secondary)',
      width: '77.34px',
      height: '54.86px',
      right: '5%',
      borderRadius: '8px',
      top: '0',
      transform: 'translateY(1px)',
    });
  }, 10000);

  const timestamp = '2025-10-22T23:59:59';
  const seconds = getSecondsUntilTimestamp(timestamp);
  const time = new Date().getTime() / 1000 + seconds;
  const flipdown = new FlipDown(time).start().ifEnded(() => {
    clearInterval(interval);
  });

  cta.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK2);
  });
  flipdownElement.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK3);
  });
  logoContainer.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK4);
  });

  const header = document.querySelector('.header');

  function come_header() {
    gsap.fromTo(
      header,
      {
        duration: 0.5,
        opacity: 0,
        transform: 'translateX(5px)',
      },
      {
        duration: 0.5,
        opacity: 1,
        transform: 'translateX(0px)',
      }
    );
  }

  setTimeout(() => {
    fire_tag(ALL_EVENT_TYPES.LOOP);
    location.reload();
  }, 40000);
});
