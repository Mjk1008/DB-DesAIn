const productContainers = document.querySelectorAll('.productContainer');
const products = [];
productContainers.forEach((el) => {
  products.push(el.querySelectorAll('.product'));
});
const overline = document.querySelector('.overline');
const items = document.querySelectorAll('.item');

function fadeOutGroup(index) {
  products[index].forEach((product, index) => {
    gsap.to(product, {
      duration: 0.5,
      delay: 1 + index * 0.3,
      transform: 'translateY(-200px)',
    });
  });

  setTimeout(() => {
    productContainers[index].style.opacity = '0';
    setTimeout(() => {
      products[index].forEach((product, index) => {
        gsap.set(product, {
          transform: 'translateY(0)',
        });
      });
    }, 100);
  }, 3000);
}

function fadeInGroup(index) {
  gsap.set(products[index], {
    transform: 'translateY(-200px)',
  });
  gsap.to(productContainers[index], {
    opacity: 1,
  });

  products[index].forEach((product, index) => {
    gsap.to(product, {
      transform: 'translateY(0px)',
      duration: 0.5,
      delay: 1 + index * 0.3,
    });
  });
}
fadeInGroup(0);

function startInterval() {
  let current_index = 0;
  function handler() {
    const next_index = (current_index + 1) % products.length;
    fadeOutGroup(current_index);

    const tl = gsap.timeline();
    tl.to(items[current_index], {
      opacity: 0,
      duration: 0.5,
    })
      .to(overline, {
        opacity: 1,
        duration: 0.25,
      })
      .to(overline, {
        delay: 2,
        duration: 0.25,
        opacity: 0,
      })
      .to(items[next_index], {
        opacity: 1,
        duration: 0.5,
      });

    setTimeout(() => {
      fadeInGroup(next_index);
      setTimeout(() => {
        current_index = next_index;
      }, 3500);
    }, 1000);
  }

  setInterval(handler, 7000);
}

startInterval();
