const contentElement = document.querySelector('.content');
const contentScrollHeight = contentElement.scrollHeight;
const itemsCount = Math.round(contentScrollHeight / 150) + 1;
let currentSlideNumber = 0;
const products = document.querySelectorAll('.product');
const videoContainer = document.querySelector('.videoContainer');

(function init() {
  products.forEach((value, key) => {
    if (key !== 0) {
      value.style.opacity = '0';
    }
  });
})();

function handleProduct(currentNumber, NextNumber) {
  console.log(NextNumber);
  const currentProduct = products[currentNumber % products.length];
  const nextProduct = products[NextNumber];
  
  // تنظیم محصول بعدی برای انیمیشن ورود (zoom in قوی)
  gsap.set(nextProduct, {
    opacity: 0,
    scale: 1.6,
    zIndex: 10
  });
  
  // تنظیم محصول فعلی
  gsap.set(currentProduct, {
    zIndex: 5
  });
  
  // انیمیشن خروج: fade out + zoom out (کوچک می‌شود)
  gsap.to(currentProduct, {
    duration: 0.8,
    opacity: 0,
    scale: 0.4,
    ease: "power3.in"
  });
  
  // انیمیشن ورود: fade in + zoom in با bounce effect (بزرگ می‌شود و جلب توجه می‌کند)
  gsap.to(nextProduct, {
    duration: 0.9,
    opacity: 1,
    scale: 1,
    ease: "back.out(1.4)",
    delay: 0.1
  });
}

// تابع تغییر خودکار محصولات هر 2.5 ثانیه
function startAutoPlay() {
  setInterval(() => {
    const nextSlideNumber = (currentSlideNumber + 1) % products.length;
    handleProduct(currentSlideNumber, nextSlideNumber);
    currentSlideNumber = nextSlideNumber;
  }, 2500); // هر 2.5 ثانیه
}

// شروع auto-play بعد از لود شدن صفحه
startAutoPlay();

// غیرفعال کردن تغییر بر اساس اسکرول
// window.addEventListener('message', (e) => {
//   if (e.data.type !== 'yn-window-scroll') {
//     return;
//   }
//   handleScroll(e.data.scrolled, e.data.scrolledInPx, e.data.heightOfPage);
// });



const video = document.getElementById('videoBox');
function toggleSound() {
  unmuteButton.style.opacity = video.muted ? '1' : '0.5'
  video.muted = !video.muted;
}


const unmuteButton = document.querySelector('.unmuteButton');
unmuteButton.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  toggleSound();
  fire_tag(ALL_EVENT_TYPES.CLICK4);
});


gsap.to(videoContainer, {
  duration: 1,
  bottom: "5px",
  onComplete: () => {
    videoContainer.querySelector('video').play();
  },
});
