const arrow1 = document.querySelector('.arrow1');
const arrow2 = document.querySelector('.arrow2');
const products = document.querySelectorAll('.product');

const productStyles = [...products].map((product) => product.style);

let productIndex = 0;

let hasInteraction = false;

function toright() {
  const previousProduct = products[productIndex];
  const previousProductIndex = productIndex;
  productIndex++;
  if (productIndex >= products.length) {
    productIndex = 0;
  }
  const nextProduct = products[productIndex];

  gsap.to(previousProduct, {
    opacity: 0,
    marginRight: '-10px',
    duration: 0.5,
    onComplete: () => {
      previousProduct.style = productStyles[previousProductIndex];
      previousProduct.style.opacity = 0;
    },
  });
  gsap.fromTo(
    nextProduct,
    {
      opacity: 0,
      marginLeft: '-5px',
      duration: 0.5,
    },
    {
      opacity: 1,
      marginLeft: '0px',
      onComplete: () => {
        nextProduct.style = productStyles[productIndex];
        nextProduct.style.opacity = 1;
      },
    }
  );
}

function toleft() {
  const previousProduct = products[productIndex];
  const previousProductIndex = productIndex;
  productIndex++;
  if (productIndex >= products.length) {
    productIndex = 0;
  }
  const nextProduct = products[productIndex];

  gsap.to(previousProduct, {
    opacity: 0,
    marginRight: `${previousProductIndex * 10 + 20}px`,
    duration: 0.5,
    onComplete: () => {
      previousProduct.style = productStyles[previousProductIndex];
      previousProduct.style.opacity = 0;
    },
  });

  gsap.fromTo(
    nextProduct,
    {
      opacity: 0,
      marginRight: '-5px',
      duration: 0.5,
    },
    {
      opacity: 1,
      marginRight: productStyles[productIndex].marginRight,
      onComplete: () => {
        nextProduct.style = productStyles[productIndex];
        nextProduct.style.opacity = 1;
      },
    }
  );
}

arrow1.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  toright();
  hasInteraction = true;
});

arrow2.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  toleft();
  hasInteraction = true;
});

const productContainers = document.querySelectorAll('.productContainer');

productContainers.forEach((productContainer) => {
  productContainer.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    toright();
    hasInteraction = true;
  });
});

setTimeout(() => {
  if (!hasInteraction) {
    const interval = setInterval(() => {
      if (!hasInteraction) {
        toleft();
      } else {
        clearInterval(interval);
      }
    }, 3000);
  }
}, 10000);
