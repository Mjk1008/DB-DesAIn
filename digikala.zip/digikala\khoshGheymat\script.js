document.addEventListener('DOMContentLoaded', () => {
  const offer = document.querySelector('.offer');
  const phone = document.querySelector('.phone');
  const bg_img = document.querySelector('.bg-img');
  const logo = document.querySelector('.logo');
  const overline1 = document.querySelector('.overline1');
  const overline2 = document.querySelector('.overline2');
  const cta = document.querySelector('.cta');
  const box = document.querySelector('.box');

  gsap.set([phone, box, offer], { opacity: 0 });

  gsap.set(phone, {
    xPercent: -180,
    scale: 0.8,
  });

  gsap.to(phone, {
    duration: 1,
    opacity: 1,
    scale: 1,
    xPercent: 0,
    ease: 'back.out(1.2)',
    delay: 0.1,
  });

  gsap.set(box, {
    xPercent: -180,
    scale: 0.8,
  });

  gsap.to(box, {
    duration: 1,
    opacity: 1,
    scale: 1,
    xPercent: 0,
    ease: 'back.out(1.2)',
    delay: 0.9,
  });

  gsap.set(bg_img, {
    opacity: 1,
    scaleX: 0,
  });

  gsap.to(bg_img, {
    duration: 1,
    scaleX: 1,
    ease: 'back.out(1.2)',
    delay: 1.8,
  });

  gsap.set(logo, {
    yPercent: 250,
  });

  gsap.to(logo, {
    duration: 1,
    opacity: 1,
    yPercent: 0,
    ease: 'back.out(1.2)',
    delay: 2,
  });

  gsap.set(overline1, {
    xPercent: 250,
  });

  gsap.to(overline1, {
    duration: 1,
    opacity: 1,
    xPercent: 0,
    ease: 'back.out(1.2)',
    delay: 2,
  });

  gsap.set(cta, {
    xPercent: 250,
  });

  gsap.to(cta, {
    duration: 1,
    opacity: 1,
    xPercent: 0,
    ease: 'back.out(1.2)',
    delay: 2.3,
  });

  gsap.set(offer, {
    yPercent: 10,
    scale: 0.8,
    opacity: 0,
  });

  gsap.to(offer, {
    duration: 0.8,
    opacity: 1,
    scale: 1,
    // yPercent: -10,
    ease: 'back.out(1.2)',
    delay: 2,
  });

  let showoverline1 = true;

  const alternateOverline = () => {
    if (showoverline1) {
      gsap.to(overline1, {
        scaleX: 0,
        opacity: 0,
        duration: 0.4,
        ease: 'power2.in',
        onComplete: () => {
          gsap.fromTo(
            overline2,
            {
              scaleX: 0,
              opacity: 0,
            },
            {
              scaleX: 1,
              opacity: 1,
              duration: 0.5,
              ease: 'back.out(1.5)',
            }
          );
        },
      });
    } else {
      gsap.to(overline2, {
        scaleX: 0,
        opacity: 0,
        duration: 0.4,
        ease: 'power2.in',
        onComplete: () => {
          gsap.fromTo(
            overline1,
            {
              scaleX: 0,
              opacity: 0,
            },
            {
              scaleX: 1,
              opacity: 1,
              duration: 0.5,
              ease: 'back.out(1.5)',
            }
          );
        },
      });
    }
    showoverline1 = !showoverline1;
  };

  setTimeout(() => {
    setInterval(alternateOverline, 3500);
  }, 1000);
  setTimeout(() => {
    location.reload();
  }, 35000);
});
