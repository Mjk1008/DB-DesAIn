const unmuteButton = document.querySelector('.unmuteButton');
const video = document.querySelector('video');
const videoContainer = document.querySelector('.videoContainer');
const bg = document.querySelector('.bg');
const logo = document.querySelector('.logo');
const overline = document.querySelector('.overline');
const cta = document.querySelector('.cta');
const box = document.querySelector('.box');
const barf = document.querySelector('.barf');
const phone = document.querySelector('.phone');
const pin = document.querySelector('.pin');
const badge = document.querySelector('.badge');

const tl = gsap.timeline({});

tl.to(bg, {
  duration: 1,
  transform: 'scaleX(1)',
});

tl.to(logo, {
  duration: 1,
  left: 'calc(5% + 5px)',
  opacity: 1,
  onComplete: () => {
    gsap.to(overline, {
      duration: 1,
      bottom: '40px',
      opacity: 1,
      onComplete: () => {
        gsap.to(cta, {
          opacity: 1,
          duration: 0.5,
        });
      },
    });

    gsap.to(videoContainer, {
      delay: 1,
      duration: 1,
      bottom: '0px',
      onComplete: () => {
        video.play();
        setTimeout(goSlide2, 10000);
      },
    });
  },
});

let flag_unmute = false;
unmuteButton.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  if (!flag_unmute) {
    flag_unmute = true;
    fire_tag(ALL_EVENT_TYPES.CLICK1);
  }
  video.muted = !video.muted;
});

function goSlide2() {
  box.style.opacity = 1;
  barf.style.opacity = 1;
  tl.to(videoContainer, {
    duration: 1,
    bottom: '-150px',
  });
  tl.to(phone, {
    opacity: 1,
    bottom: '40px',
    duration: 1,
    onComplete: () => {
      gsap.to(pin, {
        opacity: 1,
        duration: 1,
      });

      gsap.to(badge, {
        opacity: 1,
        duration: 1,
      });

      setTimeout(() => {
        location.reload();
      }, 11000);
    },
  });
}
