const unmuteButton = document.querySelector('.unmuteButton');
const video = document.querySelector('video');
const videoContainer = document.querySelector('.videoContainer');
const bg = document.querySelector('.bg');
const logo = document.querySelector('.logo');
const overline = document.querySelector('.overline');
const cta = document.querySelector('.cta');
const box = document.querySelector('.box');
const barf = document.querySelector('.barf');
const phone = document.querySelector('.phone');
const pin = document.querySelector('.pin');
const badge = document.querySelector('.badge');

const tl = gsap.timeline({});

tl.to(bg, {
  duration: 1,
  transform: 'scaleX(1)',
});

tl.to(logo, {
  duration: 1,
  left: 'calc(5% + 5px)',
  opacity: 1,
  onComplete: () => {
    gsap.to(overline, {
      duration: 1,
      bottom: '40px',
      opacity: 1,
      onComplete: () => {
        gsap.to(cta, {
          opacity: 1,
          duration: 0.5,
        });
      },
    });

    gsap.to(box, {
      opacity: 1,
      delay: 1,
      duration: 1,
      onComplete: () => {
        gsap.to(phone, {
          opacity: 1,
          duration: 1,
          bottom: '40px',
          onComplete: () => {
            gsap.to(pin, {
              opacity: 1,
              duration: 1,
            });
            gsap.to(badge, {
              opacity: 1,
              duration: 1,
              onComplete: () => {
                setTimeout(goToSlide2, 5000);
              },
            });
          },
        });
        gsap.to(barf, {
          opacity: 1,
          duration: 1,
        });
      },
    });
  },
});

function goToSlide2() {
  gsap.to(videoContainer, {
    bottom: '0',
    duration: 1,
    onComplete: () => {
      video.play();
      setTimeout(() => {
        fire_tag(ALL_EVENT_TYPES.LOOP);
        location.reload();
      }, 11500);
    },
  });
  setTimeout(() => {
    phone.remove();
    box.remove();
    barf.remove();
    pin.remove();
    badge.remove();
  }, 400);
}

let flag_unmute = false;
unmuteButton.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  if (!flag_unmute) {
    flag_unmute = true;
    fire_tag(ALL_EVENT_TYPES.CLICK1);
  }
  video.muted = !video.muted;
});

cta.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK2);
});
logo.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK3);
});
videoContainer.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK4);
});
barf.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK5);
});
phone.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK5);
});
box.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK5);
});
videoContainer.addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK6);
});
