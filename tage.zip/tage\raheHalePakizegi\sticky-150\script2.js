const products = document.querySelectorAll('.product');
const contentElement = document.querySelector('.content');
const bgs = document.querySelectorAll('.bg');
let currentSlideNumber = 0;
const unmuteButton = document.querySelector('.unmuteButton');

function toggleSound(e) {
  e.preventDefault();
  e.stopPropagation();
  const video = document.getElementById('myVideo');
  video.muted = !video.muted;
}

unmuteButton.addEventListener('click', toggleSound);

(function init() {
  bgs.forEach((bg, index) => {
    bg.style.opacity = index === 0 ? '1' : '0';
  });
  products.forEach((product, index) => {
    product.style.opacity = index === 0 ? '1' : '0';
  });
})();

function handleProducts(currentNumber, nextNumber) {
  if (nextNumber >= products.length) return;
  gsap.to(products[currentNumber], {
    duration: 0.5,
    opacity: 0,
    onComplete: () => {
      gsap.to(products[nextNumber], {
        duration: 0.5,
        opacity: 1,
      });
    },
  });
}

function goToSlide(slideNumber) {
  gsap.to(contentElement, {
    duration: 0.5,
    scrollTo: { x: 0, y: slideNumber * 120 },
    ease: 'power2.inOut',
  });
  if (slideNumber == 0) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE01);
  } else if (slideNumber == 1) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE02);
  } else if (slideNumber == 2) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE03);
  } else if (slideNumber == 3) {
    fire_tag(ALL_EVENT_TYPES.VISIT_SLIDE04);
  }
  handleProducts(currentSlideNumber, slideNumber);
}

let isScrolling = false;

function handleScroll(percent, scrollPx, heightOfPage) {
  if (isScrolling) return;

  isScrolling = true;
  const withPercent = heightOfPage < 3500;
  let newSlideNumber;

  if (withPercent) {
    newSlideNumber = Math.round((percent / 200) * (3 - 1));
  } else {
    newSlideNumber = Math.floor(scrollPx / 500);
  }
  newSlideNumber %= 3;

  if (newSlideNumber === currentSlideNumber) {
    isScrolling = false;
    return;
  }

  handleProducts(currentSlideNumber, newSlideNumber);

  currentSlideNumber = newSlideNumber;

  goToSlide(currentSlideNumber);

  setTimeout(() => {
    isScrolling = false;
  }, 1000);
}

window.addEventListener('message', (e) => {
  if (e.data.type !== 'yn-window-scroll') {
    return;
  }
  handleScroll(e.data.scrolled, e.data.scrolledInPx, e.data.heightOfPage);
});

document.querySelector('.logo').addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK_LOGO);
});

products.forEach((product) => {
  product.addEventListener('click', () => {
    fire_tag(ALL_EVENT_TYPES.CLICK_PRODUCT);
  });
});

document.querySelector('.videoContainer').addEventListener('click', () => {
  fire_tag(ALL_EVENT_TYPES.CLICK_VIDEO);
});
